
<?php
require_once "conexion.php";

$buscar = trim($_GET["buscar"] ?? "");
$filtro = trim($_GET["filtro"] ?? "todos");

$sql = "
    SELECT
        m.id_mantenimiento,
        m.id_instrumento,
        m.id_encargado,
        m.fecha_inicio,
        m.descripcion_falla,
        m.estado_mantenimiento,
        m.tipo,
        m.fecha_ingreso,
        m.fecha_completado,
        i.nombre AS nombre_instrumento,
        i.num_serie,
        i.marca,
        e.nombre AS nombre_encargado,
        e.apellido AS apellido_encargado
    FROM mantenimientos m
    INNER JOIN Instrumentos i
        ON m.id_instrumento = i.id_instrumento
    LEFT JOIN encargado e
        ON m.id_encargado = e.id_encargado
    WHERE 1=1
";

if ($buscar !== "") {
    $sql .= "
        AND (
            i.nombre LIKE ?
            OR CAST(i.num_serie AS CHAR) LIKE ?
            OR i.marca LIKE ?
            OR m.descripcion_falla LIKE ?
            OR m.estado_mantenimiento LIKE ?
            OR m.tipo LIKE ?
            OR CONCAT(e.nombre, ' ', e.apellido) LIKE ?
        )
    ";
}

if ($filtro === "realizados") {
    $sql .= "
        AND (
            m.fecha_completado IS NOT NULL
            OR LOWER(TRIM(m.estado_mantenimiento))
                IN ('realizado', 'realizada', 'completado',
                    'completada', 'finalizado', 'finalizada',
                    'terminado', 'terminada')
        )
    ";
} elseif ($filtro === "pendientes") {
    $sql .= "
        AND m.fecha_completado IS NULL
        AND LOWER(TRIM(m.estado_mantenimiento))
            NOT IN ('realizado', 'realizada', 'completado',
                    'completada', 'finalizado', 'finalizada',
                    'terminado', 'terminada')
    ";
}

$sql .= " ORDER BY m.fecha_inicio DESC, m.id_mantenimiento DESC";

$stmt = $conexion->prepare($sql);

if (!$stmt) {
    die("Error al preparar la consulta: " .
        htmlspecialchars($conexion->error, ENT_QUOTES, 'UTF-8'));
}

if ($buscar !== "") {
    $termino = "%" . $buscar . "%";
    $stmt->bind_param(
        "sssssss",
        $termino,
        $termino,
        $termino,
        $termino,
        $termino,
        $termino,
        $termino
    );
}

$stmt->execute();
$resultado = $stmt->get_result();

$total = 0;
$realizados = 0;
$pendientes = 0;

if ($resultado) {
    while ($fila = $resultado->fetch_assoc()) {
        $total++;

        $estado = strtolower(trim($fila["estado_mantenimiento"] ?? ""));
        $fechaCompletado = $fila["fecha_completado"];

        $estaRealizado = !empty($fechaCompletado) ||
            in_array($estado, [
                "realizado", "realizada",
                "completado", "completada",
                "finalizado", "finalizada",
                "terminado", "terminada"
            ], true);

        if ($estaRealizado) {
            $realizados++;
        } else {
            $pendientes++;
        }
    }

    $resultado->data_seek(0);
}

function escapar($valor) {
    return htmlspecialchars((string)($valor ?? ""), ENT_QUOTES, "UTF-8");
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Mantenimientos | BandaStock</title>

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        :root {
            --azul: #17365D;
            --dorado: #D4AF37;
            --fondo: #F4F6F8;
            --blanco: #FFFFFF;
            --texto: #263238;
            --borde: #DDE3E8;
            --verde: #198754;
            --rojo: #C0392B;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: var(--fondo);
            color: var(--texto);
        }

        header {
            background: var(--azul);
            color: var(--blanco);
            padding: 22px 16px;
            border-bottom: 5px solid var(--dorado);
        }

        .encabezado {
            max-width: 1200px;
            margin: auto;
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .encabezado i {
            color: var(--dorado);
            font-size: 32px;
        }

        header h1 {
            margin: 0;
            font-size: 25px;
        }

        header p {
            margin: 6px 0 0;
            color: #E5EAF0;
            font-size: 14px;
        }

        main {
            max-width: 1200px;
            margin: 28px auto;
            padding: 0 16px;
        }

        .resumen {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 16px;
            margin-bottom: 22px;
        }

        .tarjeta {
            background: var(--blanco);
            border-radius: 10px;
            padding: 20px;
            border-left: 5px solid var(--dorado);
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.06);
        }

        .tarjeta i {
            color: var(--azul);
            font-size: 23px;
            margin-bottom: 10px;
        }

        .tarjeta p {
            margin: 0 0 7px;
            color: #5F6B76;
        }

        .tarjeta h2 {
            margin: 0;
            color: var(--azul);
            font-size: 28px;
        }

        .panel {
            background: var(--blanco);
            border-radius: 10px;
            padding: 22px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.06);
        }

        .panel h2 {
            color: var(--azul);
            margin-top: 0;
            font-size: 20px;
        }

        .buscador {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 20px;
        }

        .buscador input,
        .buscador select {
            flex: 1;
            min-width: 180px;
            padding: 12px;
            border: 1px solid var(--borde);
            border-radius: 6px;
            font-size: 14px;
            background: white;
        }

        .boton {
            border: none;
            border-radius: 6px;
            padding: 12px 16px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .boton-buscar {
            background: var(--azul);
            color: white;
        }

        .boton-limpiar {
            background: var(--dorado);
            color: #17212B;
        }

        .tabla-contenedor {
            width: 100%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            min-width: 1100px;
            border-collapse: collapse;
        }

        thead {
            background: var(--azul);
            color: white;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid var(--borde);
            vertical-align: top;
        }

        th {
            font-size: 13px;
            white-space: nowrap;
        }

        td {
            font-size: 14px;
            line-height: 1.4;
        }

        tbody tr:hover {
            background: #F8FAFC;
        }

        .estado {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            white-space: nowrap;
        }

        .realizado {
            background: #D9F2E3;
            color: #17663A;
        }

        .pendiente {
            background: #FBE2E0;
            color: #922B21;
        }

        .sin-resultados {
            text-align: center;
            padding: 25px;
            color: #64717D;
        }

        .nota {
            color: #64717D;
            font-size: 13px;
            line-height: 1.5;
            margin-top: 16px;
        }

        @media (max-width: 700px) {
            .resumen {
                grid-template-columns: 1fr;
            }

            .buscador {
                flex-direction: column;
            }

            .buscador input,
            .buscador select {
                width: 100%;
            }

            .boton {
                width: 100%;
            }

            .panel {
                padding: 15px;
            }

            header h1 {
                font-size: 21px;
            }
        }
    </style>
</head>

<body>

<header>
    <div class="encabezado">
        <i class="fa-solid fa-screwdriver-wrench"></i>
        <div>
            <h1>BandaStock</h1>
            <p>Consulta de mantenimientos realizados y pendientes</p>
        </div>
    </div>
</header>

<main>
    <section class="resumen">
        <div class="tarjeta">
            <i class="fa-solid fa-list-check"></i>
            <p>Mantenimientos encontrados</p>
            <h2><?= $total ?></h2>
        </div>

        <div class="tarjeta">
            <i class="fa-solid fa-circle-check"></i>
            <p>Realizados</p>
            <h2><?= $realizados ?></h2>
        </div>

        <div class="tarjeta">
            <i class="fa-solid fa-clock"></i>
            <p>Pendientes</p>
            <h2><?= $pendientes ?></h2>
        </div>
    </section>

    <section class="panel">
        <h2>
            <i class="fa-solid fa-magnifying-glass"></i>
            Buscar mantenimientos
        </h2>

        <form method="GET" class="buscador">
            <input
                type="text"
                name="buscar"
                placeholder="Instrumento, serie, marca, falla o encargado..."
                value="<?= escapar($buscar) ?>"
            >

            <select name="filtro">
                <option value="todos"
                    <?= $filtro === "todos" ? "selected" : "" ?>>
                    Todos los mantenimientos
                </option>

                <option value="realizados"
                    <?= $filtro === "realizados" ? "selected" : "" ?>>
                    Realizados
                </option>

                <option value="pendientes"
                    <?= $filtro === "pendientes" ? "selected" : "" ?>>
                    Pendientes
                </option>
            </select>

            <button type="submit" class="boton boton-buscar">
                <i class="fa-solid fa-search"></i> Buscar
            </button>

            <a href="mantenimientos_realizados_pendientes.php"
               class="boton boton-limpiar">
                <i class="fa-solid fa-rotate-left"></i> Limpiar
            </a>
        </form>

        <div class="tabla-contenedor">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Instrumento</th>
                        <th>Serie</th>
                        <th>Tipo</th>
                        <th>Descripción de la falla</th>
                        <th>Fecha de inicio</th>
                        <th>Fecha de ingreso</th>
                        <th>Fecha de completado</th>
                        <th>Encargado</th>
                        <th>Estado del mantenimiento</th>
                    </tr>
                </thead>

                <tbody>
                <?php if ($resultado && $resultado->num_rows > 0): ?>
                    <?php while ($fila = $resultado->fetch_assoc()): ?>
                        <?php
                            $estadoTexto = trim(
                                $fila["estado_mantenimiento"] ?? ""
                            );

                            $estadoMinuscula = strtolower($estadoTexto);

                            $estaRealizado =
                                !empty($fila["fecha_completado"]) ||
                                in_array($estadoMinuscula, [
                                    "realizado", "realizada",
                                    "completado", "completada",
                                    "finalizado", "finalizada",
                                    "terminado", "terminada"
                                ], true);

                            $clase = $estaRealizado
                                ? "realizado"
                                : "pendiente";

                            $etiqueta = $estaRealizado
                                ? "Realizado"
                                : "Pendiente";
                        ?>

                        <tr>
                            <td><?= escapar($fila["id_mantenimiento"]) ?></td>
                            <td><?= escapar($fila["nombre_instrumento"]) ?></td>
                            <td><?= escapar($fila["num_serie"]) ?></td>
                            <td><?= escapar($fila["tipo"]) ?></td>
                            <td><?= escapar($fila["descripcion_falla"]) ?></td>
                            <td><?= escapar($fila["fecha_inicio"]) ?></td>
                            <td><?= escapar($fila["fecha_ingreso"]) ?></td>
                            <td>
                                <?= !empty($fila["fecha_completado"])
                                    ? escapar($fila["fecha_completado"])
                                    : "Pendiente" ?>
                            </td>
                            <td>
                                <?= escapar(
                                    trim(
                                        ($fila["nombre_encargado"] ?? "") . " " .
                                        ($fila["apellido_encargado"] ?? "")
                                    ) ?: "Sin asignar"
                                ) ?>
                            </td>
                            <td>
                                <span class="estado <?= $clase ?>">
                                    <?= escapar($etiqueta) ?>
                                </span>
                                <br>
                                <small><?= escapar($estadoTexto) ?></small>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="10" class="sin-resultados">
                            <i class="fa-solid fa-circle-info"></i>
                            No se encontraron mantenimientos.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <p class="nota">
            Se considera realizado un mantenimiento cuando tiene fecha de
            completado o un estado reconocido como realizado, completado,
            finalizado o terminado. Los demás registros se muestran como
            pendientes. Ajusta estas condiciones si tu base utiliza otros
            valores en estado_mantenimiento.
        </p>
    </section>
</main>

</body>
</html>

<?php
$stmt->close();
$conexion->close();
?>
