
<?php
session_start();
require_once 'conexion.php';

// VERIFICAR SESIÓN
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

$rol = strtolower(trim($_SESSION['rol'] ?? ''));

if (!in_array($rol, ['encargado', 'usuario'], true)) {
    header("Location: bienvenida.php");
    exit();
}

$mensaje = '';
$tipo_alerta = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // SOLO EL ENCARGADO PUEDE REGISTRAR DEVOLUCIONES
    if ($rol !== 'encargado') {
        header("Location: devolucion.php");
        exit();
    }

    $id_prestamo = filter_input(
        INPUT_POST,
        'id_prestamo',
        FILTER_VALIDATE_INT
    );

    $fecha_devolucion = trim(
        $_POST['fecha_devolucion_real'] ?? ''
    );

    $fecha = DateTime::createFromFormat(
        '!Y-m-d',
        $fecha_devolucion
    );

    if (!$id_prestamo || !$fecha_devolucion || !$fecha ||
        $fecha->format('Y-m-d') !== $fecha_devolucion) {

        $mensaje = 'Selecciona un préstamo y una fecha válida.';
        $tipo_alerta = 'error';

    } elseif ($fecha_devolucion > date('Y-m-d')) {

        $mensaje = 'La fecha de devolución no puede ser futura.';
        $tipo_alerta = 'error';

    } else {

        try {
            $conexion->begin_transaction();

            // CONSULTAR EL PRÉSTAMO Y BLOQUEAR SU REGISTRO
            $sql = "SELECT id_instrumento, fecha_prestamo,
                           fecha_devolucion_real
                    FROM prestamos
                    WHERE id_prestamo = ?
                    FOR UPDATE";

            $stmt = $conexion->prepare($sql);
            $stmt->bind_param("i", $id_prestamo);
            $stmt->execute();

            $resultado = $stmt->get_result();
            $prestamo = $resultado->fetch_assoc();
            $stmt->close();

            if (!$prestamo) {
                throw new Exception(
                    'El préstamo seleccionado no existe.'
                );
            }

            if ($prestamo['fecha_devolucion_real'] !== null) {
                throw new Exception(
                    'Este préstamo ya tiene registrada una devolución.'
                );
            }

            if ($fecha_devolucion < $prestamo['fecha_prestamo']) {
                throw new Exception(
                    'La devolución no puede ser anterior al préstamo.'
                );
            }

            $id_instrumento = (int)$prestamo['id_instrumento'];

            // REGISTRAR LA DEVOLUCIÓN EN EL PRÉSTAMO
            $sql = "UPDATE prestamos
                    SET fecha_devolucion_real = ?,
                        estado_prestamo = 'Devuelto'
                    WHERE id_prestamo = ?
                      AND fecha_devolucion_real IS NULL";

            $stmt = $conexion->prepare($sql);
            $stmt->bind_param(
                "si",
                $fecha_devolucion,
                $id_prestamo
            );
            $stmt->execute();

            if ($stmt->affected_rows !== 1) {
                $stmt->close();
                throw new Exception(
                    'No se pudo actualizar el préstamo.'
                );
            }

            $stmt->close();

            // COMPROBAR QUE NO EXISTA OTRO PRÉSTAMO PENDIENTE
            $sql = "SELECT COUNT(*) AS pendientes
                    FROM prestamos
                    WHERE id_instrumento = ?
                      AND fecha_devolucion_real IS NULL";

            $stmt = $conexion->prepare($sql);
            $stmt->bind_param("i", $id_instrumento);
            $stmt->execute();

            $pendientes = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            // LIBERAR EL INSTRUMENTO SI YA NO TIENE PRÉSTAMOS PENDIENTES
            if ((int)$pendientes['pendientes'] === 0) {

                $sql = "UPDATE Instrumentos
                        SET disponibilidad = 'Disponible'
                        WHERE id_instrumento = ?";

                $stmt = $conexion->prepare($sql);
                $stmt->bind_param("i", $id_instrumento);
                $stmt->execute();
                $stmt->close();
            }

            $conexion->commit();

            $mensaje = '¡Devolución registrada correctamente!';
            $tipo_alerta = 'success';

        } catch (Throwable $e) {

            $conexion->rollback();

            $mensaje = $e instanceof mysqli_sql_exception
                ? 'Ocurrió un error al guardar la devolución.'
                : $e->getMessage();

            $tipo_alerta = 'error';
        }
    }
}

// CONSULTAR PRÉSTAMOS PENDIENTES
$sql = "SELECT p.id_prestamo, p.fecha_prestamo,
               p.fecha_devolucion_prevista,
               i.nombre AS instrumento,
               i.num_serie,
               inte.nombre AS nombre_integrante,
               inte.apellido AS apellido_integrante
        FROM prestamos p
        INNER JOIN Instrumentos i
            ON p.id_instrumento = i.id_instrumento
        INNER JOIN integrantes inte
            ON p.id_integrante = inte.id_integrante
        WHERE p.fecha_devolucion_real IS NULL
        ORDER BY p.fecha_devolucion_prevista ASC";

$prestamos = $conexion->query($sql);

// CONSULTAR HISTORIAL DE DEVOLUCIONES
$sql_historial = "SELECT p.id_prestamo,
                         p.fecha_prestamo,
                         p.fecha_devolucion_real,
                         p.estado_prestamo,
                         i.nombre AS instrumento,
                         inte.nombre AS nombre_integrante,
                         inte.apellido AS apellido_integrante
                  FROM prestamos p
                  INNER JOIN Instrumentos i
                      ON p.id_instrumento = i.id_instrumento
                  INNER JOIN integrantes inte
                      ON p.id_integrante = inte.id_integrante
                  WHERE p.fecha_devolucion_real IS NOT NULL
                  ORDER BY p.fecha_devolucion_real DESC";

$historial = $conexion->query($sql_historial);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Devoluciones | BandaStock</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Roboto:wght@400;500&display=swap"
          rel="stylesheet">

    <style>
        :root {
            --azul: #102A43;
            --dorado: #D4A72C;
            --blanco: #FFFFFF;
            --fondo: #F4F6F9;
            --texto: #263445;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            background: var(--fondo);
            color: var(--texto);
            font-family: 'Roboto', sans-serif;
        }

        .main-wrapper {
            max-width: 780px;
            margin: auto;
            padding: 30px 16px;
        }

        .card {
            background: var(--blanco);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 22px #102A431A;
            margin-bottom: 25px;
        }

        .card-header {
            background: var(--azul);
            color: var(--blanco);
            padding: 24px 28px;
            border-bottom: 5px solid var(--dorado);
        }

        .card-header h2 {
            font-family: 'Poppins', sans-serif;
            margin: 0 0 5px;
        }

        .card-header p {
            margin: 0;
            color: #E3EAF1;
        }

        .contenido { padding: 25px 28px; }

        .form-group {
            display: flex;
            flex-direction: column;
            margin-bottom: 18px;
        }

        label {
            font-family: 'Poppins', sans-serif;
            font-size: 13px;
            font-weight: 600;
            color: var(--azul);
            margin-bottom: 7px;
        }

        select, input {
            width: 100%;
            padding: 12px;
            border: 1px solid #CCD5DF;
            border-radius: 6px;
            background: white;
            font-size: 14px;
        }

        select:focus, input:focus {
            outline: none;
            border-color: var(--dorado);
            box-shadow: 0 0 0 3px #D4A72C30;
        }

        .btn-submit {
            width: 100%;
            padding: 13px;
            border: 0;
            border-radius: 6px;
            background: var(--dorado);
            color: var(--azul);
            font-family: 'Poppins', sans-serif;
            font-weight: 700;
            cursor: pointer;
        }

        .btn-submit:hover { background: #E4BA48; }

        .alert {
            margin: 20px 28px 0;
            padding: 12px;
            border-radius: 6px;
        }

        .success { background: #E7F6EC; color: #176536; }
        .error { background: #FCE8E8; color: #A32121; }

        .table-wrap { overflow-x: auto; }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #E1E7ED;
        }

        th {
            background: var(--azul);
            color: white;
            font-family: 'Poppins', sans-serif;
            white-space: nowrap;
        }

        tr:hover td { background: #F8FAFC; }

        .acciones {
            text-align: center;
            padding: 10px 0 25px;
        }

        a { color: var(--azul); }

        .print-btn {
            border: 1px solid var(--azul);
            background: white;
            padding: 9px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            color: var(--azul);
        }

        .sin-datos {
            padding: 18px;
            background: #F4F6F9;
            border-radius: 6px;
        }

        @media print {
            body { background: white; }
            .no-print, form, .acciones { display: none !important; }
            .main-wrapper { max-width: none; padding: 0; }
            .card { box-shadow: none; border: 1px solid #ccc; }
            .card-header { background: white; color: black; border-bottom: 2px solid #777; }
            .card-header p { color: black; }
            th { background: #eee; color: black; }
        }
    </style>
</head>

<body>
<div class="main-wrapper">

    <div class="card">
        <div class="card-header">
            <h2>Registro de devoluciones</h2>
            <p>Registra la devolución de instrumentos prestados.</p>
        </div>

        <?php if ($mensaje !== ''): ?>
            <div class="alert <?php echo $tipo_alerta; ?>">
                <?php echo htmlspecialchars($mensaje); ?>
            </div>
        <?php endif; ?>

        <div class="contenido">
            <?php if ($rol === 'encargado'): ?>

                <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>"
                      method="POST">

                    <div class="form-group">
                        <label for="id_prestamo">Préstamo pendiente:</label>

                        <select name="id_prestamo" id="id_prestamo" required>
                            <option value="">Selecciona un préstamo</option>

                            <?php if ($prestamos): ?>
                                <?php while ($fila = $prestamos->fetch_assoc()): ?>
                                    <option value="<?php echo (int)$fila['id_prestamo']; ?>">
                                        <?php echo htmlspecialchars(
                                            '#' . $fila['id_prestamo'] .
                                            ' - ' . $fila['instrumento'] .
                                            ' - Serie ' . $fila['num_serie'] .
                                            ' - ' . $fila['nombre_integrante'] .
                                            ' ' . $fila['apellido_integrante'] .
                                            ' - Debía devolver: ' .
                                            $fila['fecha_devolucion_prevista']
                                        ); ?>
                                    </option>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="fecha_devolucion_real">
                            Fecha de devolución real:
                        </label>

                        <input
                            type="date"
                            name="fecha_devolucion_real"
                            id="fecha_devolucion_real"
                            max="<?php echo date('Y-m-d'); ?>"
                            value="<?php echo date('Y-m-d'); ?>"
                            required>
                    </div>

                    <button type="submit" class="btn-submit">
                        Registrar devolución
                    </button>
                </form>

            <?php else: ?>

                <div class="sin-datos">
                    Tu rol permite consultar e imprimir, pero no registrar devoluciones.
                </div>

            <?php endif; ?>
        </div>
    </div>

   

    <div class="acciones no-print">
        <a href="bienvenida.php">Volver al menú principal</a>
    </div>

</div>
</body>
</html>
