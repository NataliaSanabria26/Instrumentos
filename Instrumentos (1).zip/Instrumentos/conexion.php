<?php
$host ="sql103.infinityfree.com"; 
$usuario ="if0_42365459"; 
$contrasena ="Lachimolala25"; 
$base_de_datos ="if0_42365459_instrumentos"; 

// Crear conexión
$conexion = mysqli_connect($host, $usuario, $contrasena, $base_de_datos);

// Verificar conexión
if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}
//cho "Conexión exitosa sombrita";

mysqli_set_charset($conexion, "utf8mb4")
?>