
<?php
    
session_start();

if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

$rol = strtolower(trim($_SESSION['rol'] ?? ''));

if ($rol !== 'encargado') {
    header("Location: bienvenida.php");
    exit();
}


include('conexion.php');

$mensaje = '';
$tipo_alerta = '';

// CARGAR CATEGORÍAS
$categorias = $conexion->query(
    "SELECT id_categoria, nombre_categoria
     FROM categoria
     ORDER BY nombre_categoria"
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id_categoria = trim($_POST['id_categoria'] ?? '');
    $nombre = trim($_POST['nombre'] ?? '');
    $num_serie = trim($_POST['num_serie'] ?? '');
    $marca = trim($_POST['marca'] ?? '');
    $estado = trim($_POST['estado'] ?? '');
    $disponibilidad = trim($_POST['disponibilidad'] ?? '');

    if (
        $id_categoria === '' ||
        $nombre === '' ||
        $num_serie === '' ||
        $marca === '' ||
        $estado === '' ||
        $disponibilidad === ''
    ) {
        $mensaje = "Todos los campos son obligatorios.";
        $tipo_alerta = "alert-error";

    } elseif (
        !ctype_digit($id_categoria) ||
        !ctype_digit($num_serie) ||
        (int)$num_serie < 0
    ) {
        $mensaje = "La categoría y el número de serie deben ser números válidos.";
        $tipo_alerta = "alert-error";

    } elseif (
        !in_array($estado, ['Bueno', 'Dañado', 'En mantenimiento'], true) ||
        !in_array($disponibilidad, ['Disponible', 'Prestado', 'No disponible'], true)
    ) {
        $mensaje = "Selecciona un estado y una disponibilidad válidos.";
        $tipo_alerta = "alert-error";

    } else {

        // VERIFICAR QUE EXISTA LA CATEGORÍA
        $sql_categoria = "SELECT id_categoria FROM categoria
                          WHERE id_categoria = ?";

        $stmt_categoria = $conexion->prepare($sql_categoria);
        $stmt_categoria->bind_param("i", $id_categoria);
        $stmt_categoria->execute();
        $resultado_categoria = $stmt_categoria->get_result();

        if ($resultado_categoria->num_rows === 0) {

            $mensaje = "La categoría seleccionada no existe.";
            $tipo_alerta = "alert-error";

        } else {

            // VERIFICAR NÚMERO DE SERIE
            $sql_verificar = "SELECT id_instrumento FROM Instrumentos
                              WHERE num_serie = ?";

            $stmt_verificar = $conexion->prepare($sql_verificar);
            $stmt_verificar->bind_param("i", $num_serie);
            $stmt_verificar->execute();
            $resultado = $stmt_verificar->get_result();

            if ($resultado->num_rows > 0) {

                $mensaje = "Este número de serie ya está registrado.";
                $tipo_alerta = "alert-error";

            } else {

                // REGISTRAR INSTRUMENTO
                $sql_insert = "INSERT INTO Instrumentos
                    (id_categoria, nombre, num_serie, marca, estado, disponibilidad)
                    VALUES (?, ?, ?, ?, ?, ?)";

                $stmt_insert = $conexion->prepare($sql_insert);

                if ($stmt_insert) {

                    $id_categoria = (int)$id_categoria;
                    $num_serie = (int)$num_serie;

                    $stmt_insert->bind_param(
                        "isisss",
                        $id_categoria,
                        $nombre,
                        $num_serie,
                        $marca,
                        $estado,
                        $disponibilidad
                    );

                    if ($stmt_insert->execute()) {
                        $mensaje = "¡Instrumento registrado exitosamente!";
                        $tipo_alerta = "alert-success";
                    } else {
                        $mensaje = "Error al registrar el instrumento.";
                        $tipo_alerta = "alert-error";
                    }

                    $stmt_insert->close();

                } else {
                    $mensaje = "Error al preparar el registro.";
                    $tipo_alerta = "alert-error";
                }
            }

            $stmt_verificar->close();
        }

        $stmt_categoria->close();
    }

    // ACTUALIZAR LA LISTA DE CATEGORÍAS
    $categorias = $conexion->query(
        "SELECT id_categoria, nombre_categoria
         FROM categoria
         ORDER BY nombre_categoria"
    );
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Registro de instrumentos | BandaStock</title>

    <link rel="stylesheet" href="estilos.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Roboto:wght@400;500&display=swap"
          rel="stylesheet">

    <style>
        :root {
            --azul-marino: #102A43;
            --azul-secundario: #243F5A;
            --dorado: #D4A72C;
            --blanco: #FFFFFF;
            --fondo: #F4F6F9;
            --texto: #263445;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: var(--fondo);
            color: var(--texto);
            font-family: 'Roboto', sans-serif;
        }

        .main-wrapper {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 30px 16px;
        }

        .card {
            width: 100%;
            max-width: 760px;
            background: var(--blanco);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 22px rgba(16, 42, 67, 0.12);
            border: 1px solid #E1E7ED;
        }

        .card-header {
            background: var(--azul-marino);
            color: var(--blanco);
            padding: 25px 30px;
            border-bottom: 5px solid var(--dorado);
        }

        .card-header h2 {
            font-family: 'Poppins', sans-serif;
            margin: 0 0 6px;
            font-size: 23px;
        }

        .card-header p {
            margin: 0;
            color: #E3EAF1;
            font-size: 14px;
        }

        form {
            padding: 28px 30px;
        }

        .grid-2 {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 20px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            margin-bottom: 20px;
        }

        .form-group label {
            font-family: 'Poppins', sans-serif;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--azul-marino);
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #CCD5DF;
            border-radius: 6px;
            font-family: 'Roboto', sans-serif;
            font-size: 14px;
            background: #FFFFFF;
            color: var(--texto);
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: var(--dorado);
            box-shadow: 0 0 0 3px rgba(212, 167, 44, 0.18);
        }

        .btn-submit {
            width: 100%;
            padding: 13px;
            background: var(--dorado);
            color: var(--azul-marino);
            border: none;
            border-radius: 6px;
            font-family: 'Poppins', sans-serif;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.2s;
        }

        .btn-submit:hover {
            background: #E4BA48;
        }

        .alert {
            margin: 22px 30px 0;
            padding: 13px 15px;
            border-radius: 6px;
            font-size: 14px;
        }

        .alert-success {
            background: #E7F6EC;
            color: #176536;
            border: 1px solid #B8E3C5;
        }

        .alert-error {
            background: #FCE8E8;
            color: #A32121;
            border: 1px solid #F3C2C2;
        }

        @media (max-width: 600px) {
            .grid-2 {
                grid-template-columns: 1fr;
                gap: 0;
            }

            .card-header,
            form {
                padding: 22px 18px;
            }

            .alert {
                margin-left: 18px;
                margin-right: 18px;
            }
        }
    </style>
</head>

<body>

<div class="main-wrapper">
    <div class="card">

        <div class="card-header">
            <h2>Registro de instrumentos</h2>
            <p>Ingresa los datos del instrumento de la banda.</p>
        </div>

        <?php if (!empty($mensaje)): ?>
            <div class="alert <?php echo $tipo_alerta; ?>">
                <?php echo htmlspecialchars($mensaje); ?>
            </div>
        <?php endif; ?>

        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>"
              method="POST">

            <div class="grid-2">

                <div class="form-group">
                    <label for="id_categoria">Categoría:</label>

                    <select name="id_categoria" id="id_categoria" required>
                        <option value="">Selecciona una categoría</option>

                        <?php if ($categorias): ?>
                            <?php while ($cat = $categorias->fetch_assoc()): ?>
                                <option
                                    value="<?php echo (int)$cat['id_categoria']; ?>"
                                    <?php echo (isset($_POST['id_categoria']) &&
                                        (string)$_POST['id_categoria'] ===
                                        (string)$cat['id_categoria']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cat['nombre_categoria']); ?>
                                </option>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="nombre">Nombre del instrumento:</label>

                    <input
                        type="text"
                        name="nombre"
                        id="nombre"
                        placeholder="Ej. Trompeta"
                        maxlength="50"
                        value="<?php echo htmlspecialchars($_POST['nombre'] ?? ''); ?>"
                        required>
                </div>

                <div class="form-group">
                    <label for="num_serie">Número de serie:</label>

                    <input
                        type="number"
                        name="num_serie"
                        id="num_serie"
                        placeholder="Ingrese el número de serie"
                        min="0"
                        value="<?php echo htmlspecialchars($_POST['num_serie'] ?? ''); ?>"
                        required>
                </div>

                <div class="form-group">
                    <label for="marca">Marca:</label>

                    <input
                        type="text"
                        name="marca"
                        id="marca"
                        placeholder="Ingrese la marca"
                        maxlength="50"
                        value="<?php echo htmlspecialchars($_POST['marca'] ?? ''); ?>"
                        required>
                </div>

                <div class="form-group">
                    <label for="estado">Estado del instrumento:</label>

                    <select name="estado" id="estado" required>
                        <option value="">Selecciona el estado</option>
                        <option value="Bueno"
                            <?php echo (($_POST['estado'] ?? '') === 'Bueno') ? 'selected' : ''; ?>>
                            Bueno
                        </option>
                        <option value="Dañado"
                            <?php echo (($_POST['estado'] ?? '') === 'Dañado') ? 'selected' : ''; ?>>
                            Dañado
                        </option>
                        <option value="En mantenimiento"
                            <?php echo (($_POST['estado'] ?? '') === 'En mantenimiento') ? 'selected' : ''; ?>>
                            En mantenimiento
                        </option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="disponibilidad">Disponibilidad:</label>

                    <select name="disponibilidad" id="disponibilidad" required>
                        <option value="">Selecciona la disponibilidad</option>
                        <option value="Disponible"
                            <?php echo (($_POST['disponibilidad'] ?? '') === 'Disponible') ? 'selected' : ''; ?>>
                            Disponible
                        </option>
                        <option value="Prestado"
                            <?php echo (($_POST['disponibilidad'] ?? '') === 'Prestado') ? 'selected' : ''; ?>>
                            Prestado
                        </option>
                        <option value="No disponible"
                            <?php echo (($_POST['disponibilidad'] ?? '') === 'No disponible') ? 'selected' : ''; ?>>
                            No disponible
                        </option>
                    </select>
                </div>

            </div>

            <button type="submit" class="btn-submit">
                Guardar instrumento
            </button>

        </form>
    </div>
</div>

</body>
</html>


