<?php
// Mostrar errores para depuración (puedes comentar o quitar estas líneas al terminar)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once 'conexion.php';

// Manejo de búsqueda por término
$busqueda = isset($_GET['buscar']) ? trim($_GET['buscar']) : '';

// Consulta SQL con INNER JOIN a la tabla 'categoria' y alias
if (!empty($busqueda)) {
    $sql = "SELECT 
                i.id_instrumento,
                i.nombre AS nombre_instrumento,
                i.num_serie,
                i.marca,
                i.estado,
                i.disponibilidad,
                c.nombre_categoria AS nombre_categoria
            FROM Instrumentos i
            INNER JOIN categoria c ON i.id_categoria = c.id_categoria
            WHERE i.nombre LIKE ? OR i.num_serie LIKE ? OR i.marca LIKE ? OR c.nombre_categoria LIKE ?
            ORDER BY i.id_instrumento ASC";

    $stmt = $conexion->prepare($sql);
    $param = "%" . $busqueda . "%";
    $stmt->bind_param("ssss", $param, $param, $param, $param);
    $stmt->execute();
    $resultado = $stmt->get_result();
} else {
    $sql = "SELECT 
                i.id_instrumento,
                i.nombre AS nombre_instrumento,
                i.num_serie,
                i.marca,
                i.estado,
                i.disponibilidad,
                c.nombre_categoria AS nombre_categoria
            FROM Instrumentos i
            INNER JOIN categoria c ON i.id_categoria = c.id_categoria
            ORDER BY i.id_instrumento ASC";

    $resultado = $conexion->query($sql);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultar Instrumentos - BandaStock</title>
    <!-- Iconos FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        /* ====================================================
           VARIABLES Y ESTILOS DE BANDA STOCK
           ==================================================== */
        :root {
            --azul-oscuro: #17365D; /* Principal */
            --dorado: #D4AF37;      /* Secundario */
            --gris-claro: #F4F6F8;  /* Fondo */
            --verde-estado: #198754;/* Disponible */
            --rojo-estado: #dc3545; /* No disponible */
            --blanco: #ffffff;
            --texto-oscuro: #2b2b2b;
            --borde-color: #e2e8f0;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--gris-claro);
            color: var(--texto-oscuro);
            min-height: 100vh;
        }

        /* ENCABEZADO PRINCIPAL */
        header {
            background-color: var(--azul-oscuro);
            color: var(--blanco);
            padding: 1.2rem 2rem;
            display: flex;
            justify-content: flex-start;
            align-items: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
        }

        header h1 {
            font-size: 1.6rem;
            display: flex;
            align-items: center;
            gap: 12px;
            color: var(--blanco);
        }

        header h1 i {
            color: var(--dorado);
        }

        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1.5rem;
        }

        /* TARJETA CONTENEDORA */
        .card {
            background-color: var(--blanco);
            border-radius: 10px;
            padding: 2rem;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            border-top: 5px solid var(--dorado);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .card-title {
            color: var(--azul-oscuro);
            font-size: 1.4rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .card-title i {
            color: var(--dorado);
        }

        /* BÚSQUEDA Y BOTONES */
        .search-box {
            display: flex;
            gap: 10px;
            width: 100%;
            max-width: 450px;
        }

        .search-box input {
            width: 100%;
            padding: 0.6rem 1rem;
            border: 1px solid var(--borde-color);
            border-radius: 6px;
            outline: none;
            font-size: 0.95rem;
            transition: border-color 0.3s;
        }

        .search-box input:focus {
            border-color: var(--azul-oscuro);
        }

        .btn {
            padding: 0.6rem 1.2rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9rem;
            transition: all 0.2s ease;
        }

        .btn-azul {
            background-color: var(--azul-oscuro);
            color: var(--blanco);
        }

        .btn-azul:hover {
            background-color: #102643;
        }

        .btn-dorado {
            background-color: var(--dorado);
            color: var(--azul-oscuro);
        }

        .btn-dorado:hover {
            background-color: #c49f2e;
        }

        /* TABLA DE INSTRUMENTOS */
        .table-responsive {
            overflow-x: auto;
            margin-top: 1rem;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }

        thead tr {
            background-color: var(--azul-oscuro);
            color: var(--blanco);
        }

        th, td {
            padding: 0.85rem 1rem;
            border-bottom: 1px solid var(--borde-color);
            font-size: 0.95rem;
        }

        th {
            font-weight: 600;
        }

        tbody tr:hover {
            background-color: rgba(23, 54, 93, 0.03);
        }

        /* BADGES / ETIQUETAS */
        .badge {
            padding: 0.3rem 0.75rem;
            border-radius: 50px;
            font-size: 0.8rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .badge-disponible {
            background-color: rgba(25, 135, 84, 0.12);
            color: var(--verde-estado);
            border: 1px solid var(--verde-estado);
        }

        .badge-nodisponible {
            background-color: rgba(220, 53, 69, 0.12);
            color: var(--rojo-estado);
            border: 1px solid var(--rojo-estado);
        }

        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
            color: #6c757d;
        }

        .empty-state i {
            font-size: 3rem;
            color: var(--dorado);
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>

    <!-- Encabezado -->
    <header>
        <h1><i class="fa-solid fa-drum"></i> BandaStock</h1>
    </header>

    <div class="container">
        <div class="card">
            <div class="card-header">
                <div class="card-title">
                    <i class="fa-solid fa-guitar"></i> Consulta de Instrumentos
                </div>

                <!-- Buscador de instrumentos -->
                <form action="consultar_instrumento.php" method="GET" class="search-box">
                    <input type="text" name="buscar" placeholder="Buscar por instrumento, marca, categoría..." value="<?php echo htmlspecialchars($busqueda); ?>">
                    <button type="submit" class="btn btn-azul"><i class="fa-solid fa-magnifying-glass"></i> Buscar</button>
                    <?php if (!empty($busqueda)): ?>
                        <a href="consultar_instrumento.php" class="btn btn-dorado" title="Limpiar búsqueda"><i class="fa-solid fa-rotate-left"></i></a>
                    <?php endif; ?>
                </form>
            </div>

            <!-- Tabla de datos -->
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Categoría</th>
                            <th>Nombre</th>
                            <th>N° Serie</th>
                            <th>Marca</th>
                            <th>Estado</th>
                            <th>Disponibilidad</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($resultado && $resultado->num_rows > 0): ?>
                            <?php while ($fila = $resultado->fetch_assoc()): ?>
                                <tr>
                                    <td><strong>#<?php echo htmlspecialchars($fila['id_instrumento']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($fila['nombre_categoria']); ?></td>
                                    <td><?php echo htmlspecialchars($fila['nombre_instrumento']); ?></td>
                                    <td><code><?php echo htmlspecialchars($fila['num_serie']); ?></code></td>
                                    <td><?php echo htmlspecialchars($fila['marca']); ?></td>
                                    <td><?php echo htmlspecialchars($fila['estado']); ?></td>
                                    <td>
                                        <?php 
                                            $disp = strtolower($fila['disponibilidad']);
                                            if ($disp == 'disponible' || $disp == '1' || $disp == 'activo'): 
                                        ?>
                                            <span class="badge badge-disponible">
                                                <i class="fa-solid fa-circle-check"></i> Disponible
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-nodisponible">
                                                <i class="fa-solid fa-circle-xmark"></i> No Disponible
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7">
                                    <div class="empty-state">
                                        <i class="fa-solid fa-folder-open"></i>
                                        <p>No se encontraron instrumentos registrados<?php echo !empty($busqueda) ? ' para tu búsqueda.' : '.'; ?></p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>
</html>