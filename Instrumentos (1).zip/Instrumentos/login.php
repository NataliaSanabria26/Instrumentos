<?php
session_start();
require_once "conexion.php"; // Si usas conexionfinal.php, cambia esta línea

// Si ya hay sesión activa, redirigir al panel principal
if (isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit;
}

$error = "";

// Procesar login al enviar formulario mediante POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $usuario_form = trim($_POST['usuario'] ?? '');
    $clave_form = trim($_POST['contrasena'] ?? '');

    if (!empty($usuario_form) && !empty($clave_form)) {
        // Consultar la base de datos por el nombre de usuario
        $stmt = $conexion->prepare("SELECT id, usuario, clave, rol FROM usuarios WHERE usuario = ? LIMIT 1");
        $stmt->bind_param("s", $usuario_form);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado && $resultado->num_rows === 1) {
            $user_data = $resultado->fetch_assoc();

            // Verificación de clave en texto plano (según tu captura de phpMyAdmin)
            if ($clave_form === $user_data['clave']) {
                // Iniciar variables de sesión
                $_SESSION['usuario_id'] = $user_data['id'];
                $_SESSION['usuario'] = $user_data['usuario'];
                $_SESSION['rol'] = $user_data['rol']; // 'Encargado' o 'Usuario'

                header("Location: index.php");
                exit;
            } else {
                $error = "Contraseña incorrecta.";
            }
        } else {
            $error = "El usuario no existe.";
        }
    } else {
        $error = "Por favor, completa todos los campos.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BandaStock | Iniciar sesión</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --fondo: #050914;
            --azul: #0b1930;
            --azul-claro: #142c4d;
            --dorado: #e5b85c;
            --dorado-claro: #ffe4a0;
            --blanco: #f4f7ff;
            --gris: #98a8c2;
            --borde: rgba(160, 190, 235, 0.16);
            --rojo: #dc3545;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            min-height: 100vh;
            font-family: "Segoe UI", Arial, sans-serif;
            color: var(--blanco);
            background: radial-gradient(ellipse at 15% 15%, #10294c 0%, transparent 60%),
                        radial-gradient(ellipse at 85% 85%, #0d213e 0%, transparent 60%),
                        var(--fondo);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1.5rem;
        }

        .login-card {
            background-color: rgba(11, 25, 48, 0.85);
            border: 1px solid var(--borde);
            backdrop-filter: blur(12px);
            border-radius: 16px;
            padding: 2.5rem 2rem;
            width: 100%;
            max-width: 420px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            text-align: center;
        }

        .brand-logo {
            font-size: 2.5rem;
            color: var(--dorado);
            margin-bottom: 0.5rem;
        }

        .login-title {
            font-size: 1.8rem;
            color: var(--blanco);
            font-weight: 700;
            margin-bottom: 0.3rem;
        }

        .login-subtitle {
            font-size: 0.9rem;
            color: var(--gris);
            margin-bottom: 1.8rem;
        }

        .alert-error {
            background-color: rgba(220, 53, 69, 0.2);
            border: 1px solid var(--rojo);
            color: #ff8d97;
            padding: 0.75rem 1rem;
            border-radius: 8px;
            font-size: 0.88rem;
            margin-bottom: 1.2rem;
            text-align: left;
        }

        .form-group {
            margin-bottom: 1.2rem;
            text-align: left;
        }

        .form-group label {
            display: block;
            font-size: 0.85rem;
            color: var(--gris);
            margin-bottom: 0.4rem;
            font-weight: 600;
        }

        .input-wrapper {
            position: relative;
        }

        .input-wrapper i {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gris);
            font-size: 1rem;
        }

        .form-control {
            width: 100%;
            padding: 0.75rem 1rem 0.75rem 2.8rem;
            background-color: var(--azul-claro);
            border: 1px solid var(--borde);
            border-radius: 8px;
            color: var(--blanco);
            font-size: 0.95rem;
            outline: none;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--dorado);
            box-shadow: 0 0 8px rgba(229, 184, 92, 0.25);
        }

        .btn-submit {
            width: 100%;
            padding: 0.85rem;
            background: linear-gradient(135deg, var(--dorado) 0%, #c4963a 100%);
            border: none;
            border-radius: 8px;
            color: #050914;
            font-size: 1rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 0.8rem;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(229, 184, 92, 0.3);
        }
    </style>
</head>
<body>

    <div class="login-card">
        <div class="brand-logo">
            <i class="fa-solid fa-music"></i>
        </div>
        <h1 class="login-title">BandaStock</h1>
        <p class="login-subtitle">Ingresa tus credenciales para acceder al sistema</p>

        <?php if (!empty($error)): ?>
            <div class="alert-error">
                <i class="fa-solid fa-circle-exclamation"></i> <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form action="login.php" method="POST">
            <div class="form-group">
                <label for="usuario">Usuario</label>
                <div class="input-wrapper">
                    <i class="fa-solid fa-user"></i>
                    <input type="text" name="usuario" id="usuario" class="form-control" placeholder="Ej: Encargado" required autocomplete="off">
                </div>
            </div>

            <div class="form-group">
                <label for="contrasena">Contraseña</label>
                <div class="input-wrapper">
                    <i class="fa-solid fa-lock"></i>
                    <input type="password" name="contrasena" id="contrasena" class="form-control" placeholder="••••••••" required>
                </div>
            </div>

            <button type="submit" class="btn-submit">
                <i class="fa-solid fa-right-to-bracket"></i> Iniciar Sesión
            </button>
        </form>
    </div>

</body>
</html>
