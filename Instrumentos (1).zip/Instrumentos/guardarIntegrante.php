
<?php
session_start();
require_once 'conexion.php';

// Verificar que haya una sesión iniciada
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

$rol = strtolower(trim($_SESSION['rol'] ?? ''));

// Solo el encargado puede guardar
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $rol !== 'encargado') {
    header("Location: consultar_integrantes.php");
    exit();
}

$mensaje = '';
$tipo_alerta = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $apellido = trim($_POST['apellido'] ?? '');
    $nie = trim($_POST['NIE'] ?? '');
    $seccion = trim($_POST['seccion_grado'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');

    if (
        $nombre === '' || $apellido === '' ||
        $nie === '' || $seccion === '' || $telefono === ''
    ) {
        $mensaje = 'Todos los campos son obligatorios.';
        $tipo_alerta = 'error';

    } elseif (!ctype_digit($nie) || !ctype_digit($telefono)) {
        $mensaje = 'El NIE y el teléfono deben contener solo números.';
        $tipo_alerta = 'error';

    } else {
        $sql = "INSERT INTO integrantes
                (nombre, apellido, NIE, seccion_grado, telefono)
                VALUES (?, ?, ?, ?, ?)";

        $stmt = $conexion->prepare($sql);

        if ($stmt) {
            $stmt->bind_param(
                "ssisi",
                $nombre,
                $apellido,
                $nie,
                $seccion,
                $telefono
            );

            if ($stmt->execute()) {
                $mensaje = '¡Integrante registrado correctamente!';
                $tipo_alerta = 'success';
            } else {
                $mensaje = 'No se pudo registrar. Verifica que el NIE no esté repetido.';
                $tipo_alerta = 'error';
            }

            $stmt->close();
        } else {
            $mensaje = 'Error al preparar el registro.';
            $tipo_alerta = 'error';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de integrantes | BandaStock</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Roboto:wght@400;500&display=swap"
          rel="stylesheet">

    <style>
        :root {
            --azul: #102A43;
            --dorado: #D4A72C;
            --blanco: #FFFFFF;
            --fondo: #F4F6F9;
            --texto: #263445;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            background: var(--fondo);
            color: var(--texto);
            font-family: 'Roboto', sans-serif;
        }

        .main-wrapper {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 25px 15px;
        }

        .card {
            width: 100%;
            max-width: 720px;
            background: var(--blanco);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 22px #102A431A;
        }

        .card-header {
            background: var(--azul);
            color: var(--blanco);
            padding: 25px 30px;
            border-bottom: 5px solid var(--dorado);
        }

        h2 {
            font-family: 'Poppins', sans-serif;
            margin: 0 0 5px;
        }

        .card-header p { margin: 0; color: #E3EAF1; }

        form { padding: 28px 30px; }

        .grid-2 {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            margin-bottom: 18px;
        }

        label {
            font-family: 'Poppins', sans-serif;
            color: var(--azul);
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 7px;
        }

        input {
            width: 100%;
            padding: 12px;
            border: 1px solid #CCD5DF;
            border-radius: 6px;
            font-size: 14px;
        }

        input:focus {
            outline: 2px solid #D4A72C55;
            border-color: var(--dorado);
        }

        .btn-submit {
            width: 100%;
            padding: 13px;
            border: none;
            border-radius: 6px;
            background: var(--dorado);
            color: var(--azul);
            font-family: 'Poppins', sans-serif;
            font-weight: 700;
            cursor: pointer;
        }

        .btn-submit:hover { background: #E4BA48; }

        .alert {
            margin: 20px 30px 0;
            padding: 12px;
            border-radius: 6px;
        }

        .success { background: #E7F6EC; color: #176536; }
        .error { background: #FCE8E8; color: #A32121; }

        .acciones {
            padding: 0 30px 25px;
            text-align: center;
        }

        a { color: var(--azul); }

        @media (max-width: 580px) {
            .grid-2 { grid-template-columns: 1fr; gap: 0; }
            form { padding: 22px 18px; }
            .card-header { padding: 22px 18px; }
            .alert { margin-left: 18px; margin-right: 18px; }
        }
    </style>
</head>
<body>
<div class="main-wrapper">
    <div class="card">
        <div class="card-header">
            <h2>Registro de integrantes</h2>
            <p>Ingresa los datos del integrante de la banda.</p>
        </div>

        <?php if ($mensaje !== ''): ?>
            <div class="alert <?php echo $tipo_alerta; ?>">
                <?php echo htmlspecialchars($mensaje); ?>
            </div>
        <?php endif; ?>

        <?php if ($rol === 'encargado'): ?>
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>"
              method="POST">
            <div class="grid-2">
                <div class="form-group">
                    <label for="nombre">Nombre:</label>
                    <input type="text" id="nombre" name="nombre"
                           maxlength="50" required>
                </div>

                <div class="form-group">
                    <label for="apellido">Apellido:</label>
                    <input type="text" id="apellido" name="apellido"
                           maxlength="50" required>
                </div>

                <div class="form-group">
                    <label for="NIE">NIE:</label>
                    <input type="number" id="NIE" name="NIE"
                           min="0" required>
                </div>

                <div class="form-group">
                    <label for="seccion_grado">Sección y grado:</label>
                    <input type="text" id="seccion_grado"
                           name="seccion_grado" maxlength="50" required>
                </div>

                <div class="form-group">
                    <label for="telefono">Teléfono:</label>
                    <input type="number" id="telefono" name="telefono"
                           min="0" required>
                </div>
            </div>

            <button type="submit" class="btn-submit">
                Guardar integrante
            </button>
        </form>
        <?php else: ?>
            <div class="alert error">
                Tu rol permite consultar e imprimir, pero no registrar integrantes.
            </div>
        <?php endif; ?>

     
            <a href="bienvenida.php">Volver al menú</a>
        </div>
    </div>
</div>
</body>
</html>