
<?php
session_start();
require_once 'conexion.php';

// VERIFICAR SESIÓN Y ROL
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

$rol = strtolower(trim($_SESSION['rol'] ?? ''));

if (!in_array($rol, ['encargado', 'usuario'], true)) {
    header("Location: bienvenida.php");
    exit();
}

$mensaje = '';
$tipo_alerta = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // SOLO EL ENCARGADO PUEDE REGISTRAR MANTENIMIENTOS
    if ($rol !== 'encargado') {
        header("Location: guardarMantenimiento.php");
        exit();
    }

    $id_instrumento = filter_input(
        INPUT_POST, 'id_instrumento', FILTER_VALIDATE_INT
    );

    $id_encargado = filter_input(
        INPUT_POST, 'id_encargado', FILTER_VALIDATE_INT
    );

    $fecha_inicio = trim($_POST['fecha_inicio'] ?? '');
    $descripcion_falla = trim($_POST['descripcion_falla'] ?? '');
    $estado_mantenimiento = trim($_POST['estado_mantenimiento'] ?? '');
    $tipo = trim($_POST['tipo'] ?? '');
    $fecha_ingreso = trim($_POST['fecha_ingreso'] ?? '');
    $fecha_completado = trim($_POST['fecha_completado'] ?? '');

    $estados_validos = [
        'Pendiente',
        'En proceso',
        'Completado'
    ];

    $tipos_validos = [
        'Preventivo',
        'Correctivo'
    ];

    $validarFecha = function ($valor) {
        if ($valor === '') {
            return false;
        }

        $fecha = DateTime::createFromFormat('!Y-m-d', $valor);

        return $fecha && $fecha->format('Y-m-d') === $valor;
    };

    if (
        !$id_instrumento ||
        !$id_encargado ||
        $fecha_inicio === '' ||
        $descripcion_falla === '' ||
        $estado_mantenimiento === '' ||
        $tipo === '' ||
        $fecha_ingreso === ''
    ) {
        $mensaje = 'Completa todos los campos obligatorios.';
        $tipo_alerta = 'error';

    } elseif (
        !$validarFecha($fecha_inicio) ||
        !$validarFecha($fecha_ingreso) ||
        ($fecha_completado !== '' &&
            !$validarFecha($fecha_completado))
    ) {
        $mensaje = 'Una de las fechas ingresadas no es válida.';
        $tipo_alerta = 'error';

    } elseif (
        !in_array($estado_mantenimiento, $estados_validos, true) ||
        !in_array($tipo, $tipos_validos, true)
    ) {
        $mensaje = 'Selecciona un tipo y estado válidos.';
        $tipo_alerta = 'error';

    } elseif (
        $fecha_ingreso < $fecha_inicio ||
        ($fecha_completado !== '' &&
            $fecha_completado < $fecha_ingreso)
    ) {
        $mensaje = 'Revisa el orden de las fechas.';
        $tipo_alerta = 'error';

    } elseif (
        ($estado_mantenimiento === 'Completado' &&
            $fecha_completado === '') ||
        ($estado_mantenimiento !== 'Completado' &&
            $fecha_completado !== '')
    ) {
        $mensaje = 'Si el mantenimiento está completado, ingresa la fecha de finalización. Si sigue pendiente o en proceso, deja esa fecha vacía.';
        $tipo_alerta = 'error';

    } else {

        // VERIFICAR QUE EXISTA EL INSTRUMENTO
        $stmt = $conexion->prepare(
            "SELECT id_instrumento FROM Instrumentos
             WHERE id_instrumento = ?"
        );

        $stmt->bind_param("i", $id_instrumento);
        $stmt->execute();
        $existe_instrumento = $stmt->get_result()->num_rows > 0;
        $stmt->close();

        // VERIFICAR QUE EXISTA EL ENCARGADO
        $stmt = $conexion->prepare(
            "SELECT id_encargado FROM encargado
             WHERE id_encargado = ?"
        );

        $stmt->bind_param("i", $id_encargado);
        $stmt->execute();
        $existe_encargado = $stmt->get_result()->num_rows > 0;
        $stmt->close();

        if (!$existe_instrumento || !$existe_encargado) {
            $mensaje = 'El instrumento o el encargado seleccionado no existe.';
            $tipo_alerta = 'error';

        } else {

            // INSERTAR MANTENIMIENTO
            $sql = "INSERT INTO mantenimientos
                (
                    id_instrumento,
                    id_encargado,
                    fecha_inicio,
                    descripcion_falla,
                    estado_mantenimiento,
                    tipo,
                    fecha_ingreso,
                    fecha_completado
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

            $stmt = $conexion->prepare($sql);

            if ($stmt) {
                $fecha_completado_db =
                    $fecha_completado !== ''
                    ? $fecha_completado
                    : null;

                $stmt->bind_param(
                    "iissssss",
                    $id_instrumento,
                    $id_encargado,
                    $fecha_inicio,
                    $descripcion_falla,
                    $estado_mantenimiento,
                    $tipo,
                    $fecha_ingreso,
                    $fecha_completado_db
                );

                if ($stmt->execute()) {

                    // SI NO ESTÁ COMPLETADO, MARCAR EL INSTRUMENTO
                    // COMO EN MANTENIMIENTO
                    if ($estado_mantenimiento !== 'Completado') {
                        $stmt_estado = $conexion->prepare(
                            "UPDATE Instrumentos
                             SET estado = 'En mantenimiento',
                                 disponibilidad = 'No disponible'
                             WHERE id_instrumento = ?"
                        );

                        $stmt_estado->bind_param(
                            "i", $id_instrumento
                        );
                        $stmt_estado->execute();
                        $stmt_estado->close();
                    }

                    $mensaje = '¡Mantenimiento registrado correctamente!';
                    $tipo_alerta = 'success';

                } else {
                    $mensaje = 'No se pudo guardar el mantenimiento.';
                    $tipo_alerta = 'error';
                }

                $stmt->close();

            } else {
                $mensaje = 'Error al preparar el registro.';
                $tipo_alerta = 'error';
            }
        }
    }
}

// CARGAR INSTRUMENTOS
$instrumentos = $conexion->query(
    "SELECT id_instrumento, nombre, num_serie
     FROM Instrumentos
     ORDER BY nombre"
);

// CARGAR ENCARGADOS
$encargados = $conexion->query(
    "SELECT id_encargado, nombre, apellido
     FROM encargado
     ORDER BY apellido, nombre"
);

// HISTORIAL DE MANTENIMIENTOS
$sql_historial = "SELECT
        m.id_mantenimiento,
        m.fecha_inicio,
        m.descripcion_falla,
        m.estado_mantenimiento,
        m.tipo,
        m.fecha_ingreso,
        m.fecha_completado,
        i.nombre AS instrumento,
        i.num_serie,
        e.nombre AS nombre_encargado,
        e.apellido AS apellido_encargado
    FROM mantenimientos m
    INNER JOIN Instrumentos i
        ON m.id_instrumento = i.id_instrumento
    INNER JOIN encargado e
        ON m.id_encargado = e.id_encargado
    ORDER BY m.id_mantenimiento DESC";

$historial = $conexion->query($sql_historial);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Mantenimientos | BandaStock</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Roboto:wght@400;500&display=swap"
          rel="stylesheet">

    <style>
        :root {
            --azul: #102A43;
            --dorado: #D4A72C;
            --blanco: #FFFFFF;
            --fondo: #F4F6F9;
            --texto: #263445;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            background: var(--fondo);
            color: var(--texto);
            font-family: 'Roboto', sans-serif;
        }

        .main-wrapper {
            max-width: 780px;
            margin: auto;
            padding: 30px 16px;
        }

        .card {
            background: var(--blanco);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 22px #102A431A;
            margin-bottom: 25px;
        }

        .card-header {
            background: var(--azul);
            color: var(--blanco);
            padding: 24px 28px;
            border-bottom: 5px solid var(--dorado);
        }

        .card-header h2 {
            font-family: 'Poppins', sans-serif;
            margin: 0 0 5px;
        }

        .card-header p {
            margin: 0;
            color: #E3EAF1;
        }

        .contenido { padding: 25px 28px; }

        .grid-2 {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            margin-bottom: 18px;
        }

        label {
            font-family: 'Poppins', sans-serif;
            color: var(--azul);
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 7px;
        }

        input, select, textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #CCD5DF;
            border-radius: 6px;
            background: white;
            color: var(--texto);
            font: 14px 'Roboto', sans-serif;
        }

        textarea {
            min-height: 105px;
            resize: vertical;
        }

        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: var(--dorado);
            box-shadow: 0 0 0 3px #D4A72C30;
        }

        .btn-submit {
            width: 100%;
            padding: 13px;
            border: none;
            border-radius: 6px;
            background: var(--dorado);
            color: var(--azul);
            font-family: 'Poppins', sans-serif;
            font-weight: 700;
            cursor: pointer;
        }

        .btn-submit:hover { background: #E4BA48; }

        .alert {
            margin: 20px 28px 0;
            padding: 12px;
            border-radius: 6px;
        }

        .success { background: #E7F6EC; color: #176536; }
        .error { background: #FCE8E8; color: #A32121; }

        .table-wrap { overflow-x: auto; }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }

        th, td {
            padding: 11px;
            text-align: left;
            border-bottom: 1px solid #E1E7ED;
            vertical-align: top;
        }

        th {
            background: var(--azul);
            color: white;
            font-family: 'Poppins', sans-serif;
            white-space: nowrap;
        }

        tr:hover td { background: #F8FAFC; }

        .acciones {
            text-align: center;
            padding: 10px 0 25px;
        }

        a { color: var(--azul); }

        .print-btn {
            border: 1px solid var(--azul);
            background: white;
            padding: 9px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            color: var(--azul);
        }

        .sin-datos {
            background: #F4F6F9;
            padding: 15px;
            border-radius: 6px;
        }

        @media (max-width: 650px) {
            .grid-2 { grid-template-columns: 1fr; gap: 0; }
            .contenido { padding: 20px 16px; }
            .card-header { padding: 22px 18px; }
            .alert { margin-left: 18px; margin-right: 18px; }
        }

        @media print {
            body { background: white; }
            .no-print, form, .acciones { display: none !important; }
            .main-wrapper { max-width: none; padding: 0; }
            .card { box-shadow: none; border: 1px solid #ccc; }
            .card-header {
                background: white;
                color: black;
                border-bottom: 2px solid #777;
            }
            .card-header p { color: black; }
            th { background: #eee; color: black; }
        }
    </style>
</head>

<body>
<div class="main-wrapper">

    <div class="card">
        <div class="card-header">
            <h2>Registro de mantenimiento</h2>
            <p>Registra las fallas y reparaciones de los instrumentos.</p>
        </div>

        <?php if ($mensaje !== ''): ?>
            <div class="alert <?php echo $tipo_alerta; ?>">
                <?php echo htmlspecialchars($mensaje); ?>
            </div>
        <?php endif; ?>

        <div class="contenido">
        <?php if ($rol === 'encargado'): ?>

            <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>"
                  method="POST">

                <div class="grid-2">

                    <div class="form-group">
                        <label for="id_instrumento">Instrumento:</label>

                        <select name="id_instrumento"
                                id="id_instrumento" required>
                            <option value="">Selecciona un instrumento</option>

                            <?php if ($instrumentos): ?>
                                <?php while ($fila = $instrumentos->fetch_assoc()): ?>
                                    <option value="<?php echo (int)$fila['id_instrumento']; ?>">
                                        <?php echo htmlspecialchars(
                                            $fila['nombre'] .
                                            ' - Serie ' . $fila['num_serie']
                                        ); ?>
                                    </option>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="id_encargado">Encargado responsable:</label>

                        <select name="id_encargado"
                                id="id_encargado" required>
                            <option value="">Selecciona un encargado</option>

                            <?php if ($encargados): ?>
                                <?php while ($fila = $encargados->fetch_assoc()): ?>
                                    <option value="<?php echo (int)$fila['id_encargado']; ?>">
                                        <?php echo htmlspecialchars(
                                            $fila['nombre'] . ' ' .
                                            $fila['apellido']
                                        ); ?>
                                    </option>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="fecha_inicio">Fecha de inicio:</label>
                        <input type="date" name="fecha_inicio"
                               id="fecha_inicio" required>
                    </div>

                    <div class="form-group">
                        <label for="fecha_ingreso">Fecha de ingreso:</label>
                        <input type="date" name="fecha_ingreso"
                               id="fecha_ingreso" required>
                    </div>

                    <div class="form-group">
                        <label for="tipo">Tipo de mantenimiento:</label>
                        <select name="tipo" id="tipo" required>
                            <option value="">Selecciona el tipo</option>
                            <option value="Preventivo">Preventivo</option>
                            <option value="Correctivo">Correctivo</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="estado_mantenimiento">Estado:</label>
                        <select name="estado_mantenimiento"
                                id="estado_mantenimiento" required>
                            <option value="">Selecciona el estado</option>
                            <option value="Pendiente">Pendiente</option>
                            <option value="En proceso">En proceso</option>
                            <option value="Completado">Completado</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="fecha_completado">Fecha de finalización:</label>
                        <input type="date" name="fecha_completado"
                               id="fecha_completado">
                    </div>

                </div>

                <div class="form-group">
                    <label for="descripcion_falla">Descripción de la falla:</label>
                    <textarea name="descripcion_falla"
                              id="descripcion_falla"
                              maxlength="500"
                              placeholder="Describe la falla o reparación necesaria..."
                              required></textarea>
                </div>

                <button type="submit" class="btn-submit">
                    Guardar mantenimiento
                </button>

            </form>

        <?php else: ?>

            <div class="sin-datos">
                Tu rol permite consultar e imprimir, pero no registrar mantenimientos.
            </div>

        <?php endif; ?>
        </div>
    </div>

   

    <div class="acciones no-print">
        <a href="bienvenida.php">Volver al menú principal</a>
    </div>

</div>

<script>
const estado = document.getElementById('estado_mantenimiento');
const fechaCompletado = document.getElementById('fecha_completado');

if (estado && fechaCompletado) {
    function actualizarFecha() {
        fechaCompletado.required = estado.value === 'Completado';

        if (estado.value !== 'Completado') {
            fechaCompletado.value = '';
        }
    }

    estado.addEventListener('change', actualizarFecha);
    actualizarFecha();
}
</script>

</body>
</html>
