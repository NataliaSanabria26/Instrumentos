<?php
session_start();
require_once 'conexion.php';

// VERIFICAR SESIÓN
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

$rol = strtolower(trim($_SESSION['rol'] ?? ''));

if (!in_array($rol, ['encargado', 'usuario'], true)) {
    header("Location: bienvenida.php");
    exit();
}

$mensaje = '';
$tipo_alerta = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // SOLO EL ENCARGADO PUEDE GUARDAR
    if ($rol !== 'encargado') {
        header("Location: consultar_instrumento.php");
        exit();
    }

    $id_instrumento = filter_input(
        INPUT_POST, 'id_instrumento', FILTER_VALIDATE_INT
    );

    $id_encargado = filter_input(
        INPUT_POST, 'id_encargado', FILTER_VALIDATE_INT
    );

    $id_integrante = filter_input(
        INPUT_POST, 'id_integrante', FILTER_VALIDATE_INT
    );

    $fecha_prestamo = trim($_POST['fecha_prestamo'] ?? '');
    $fecha_prevista = trim($_POST['fecha_devolucion_prevista'] ?? '');

    if (
        !$id_instrumento || !$id_encargado || !$id_integrante ||
        $fecha_prestamo === '' || $fecha_prevista === ''
    ) {
        $mensaje = 'Completa todos los campos obligatorios.';
        $tipo_alerta = 'error';

    } elseif (
        !DateTime::createFromFormat('!Y-m-d', $fecha_prestamo) ||
        !DateTime::createFromFormat('!Y-m-d', $fecha_prevista)
    ) {
        $mensaje = 'Las fechas ingresadas no son válidas.';
        $tipo_alerta = 'error';

    } elseif ($fecha_prevista < $fecha_prestamo) {
        $mensaje = 'La fecha prevista de devolución no puede ser anterior al préstamo.';
        $tipo_alerta = 'error';

    } else {

        // VERIFICAR DISPONIBILIDAD DEL INSTRUMENTO
        $sql_instrumento = "SELECT disponibilidad
                            FROM Instrumentos
                            WHERE id_instrumento = ?";

        $stmt_instrumento = $conexion->prepare($sql_instrumento);
        $stmt_instrumento->bind_param("i", $id_instrumento);
        $stmt_instrumento->execute();

        $resultado_instrumento = $stmt_instrumento->get_result();
        $instrumento = $resultado_instrumento->fetch_assoc();

        if (!$instrumento) {
            $mensaje = 'El instrumento seleccionado no existe.';
            $tipo_alerta = 'error';

        } elseif (
            strtolower(trim($instrumento['disponibilidad'])) !== 'disponible'
        ) {
            $mensaje = 'El instrumento no está disponible para préstamo.';
            $tipo_alerta = 'error';

        } else {

            // VERIFICAR QUE EXISTA EL ENCARGADO
            $stmt_encargado = $conexion->prepare(
                "SELECT id_encargado FROM encargado WHERE id_encargado = ?"
            );
            $stmt_encargado->bind_param("i", $id_encargado);
            $stmt_encargado->execute();

            $encargado_existe =
                $stmt_encargado->get_result()->num_rows > 0;

            $stmt_encargado->close();

            // VERIFICAR QUE EXISTA EL INTEGRANTE
            $stmt_integrante = $conexion->prepare(
                "SELECT id_integrante FROM integrantes WHERE id_integrante = ?"
            );
            $stmt_integrante->bind_param("i", $id_integrante);
            $stmt_integrante->execute();

            $integrante_existe =
                $stmt_integrante->get_result()->num_rows > 0;

            $stmt_integrante->close();

            if (!$encargado_existe || !$integrante_existe) {
                $mensaje = 'El encargado o integrante seleccionado no existe.';
                $tipo_alerta = 'error';

            } else {

                // REGISTRAR PRÉSTAMO
                $sql = "INSERT INTO prestamos
                    (id_instrumento, id_encargado, id_integrante,
                     fecha_prestamo, fecha_devolucion_prevista,
                     fecha_devolucion_real, estado_prestamo)
                    VALUES (?, ?, ?, ?, ?, NULL, ?)";

                $stmt = $conexion->prepare($sql);

                if ($stmt) {
                    $estado_prestamo = 'Activo';

                    $stmt->bind_param(
                        "iiisss",
                        $id_instrumento,
                        $id_encargado,
                        $id_integrante,
                        $fecha_prestamo,
                        $fecha_prevista,
                        $estado_prestamo
                    );

                    if ($stmt->execute()) {

                        // ACTUALIZAR DISPONIBILIDAD DEL INSTRUMENTO
                        $sql_actualizar = "UPDATE Instrumentos
                            SET disponibilidad = 'Prestado'
                            WHERE id_instrumento = ?
                            AND disponibilidad = 'Disponible'";

                        $stmt_actualizar =
                            $conexion->prepare($sql_actualizar);

                        $stmt_actualizar->bind_param(
                            "i", $id_instrumento
                        );
                        $stmt_actualizar->execute();

                        if ($stmt_actualizar->affected_rows > 0) {
                            $mensaje = '¡Préstamo registrado correctamente!';
                            $tipo_alerta = 'success';
                        } else {
                            $mensaje = 'El préstamo se registró, pero revisa la disponibilidad del instrumento.';
                            $tipo_alerta = 'error';
                        }

                        $stmt_actualizar->close();

                    } else {
                        $mensaje = 'No se pudo registrar el préstamo.';
                        $tipo_alerta = 'error';
                    }

                    $stmt->close();

                } else {
                    $mensaje = 'Error al preparar el registro del préstamo.';
                    $tipo_alerta = 'error';
                }
            }
        }

        $stmt_instrumento->close();
    }
}

// CARGAR LISTAS PARA LOS SELECT
$instrumentos = $conexion->query(
    "SELECT id_instrumento, nombre, num_serie
     FROM Instrumentos
     WHERE disponibilidad = 'Disponible'
     ORDER BY nombre"
);

$integrantes = $conexion->query(
    "SELECT id_integrante, nombre, apellido
     FROM integrantes
     ORDER BY apellido, nombre"
);

$encargados = $conexion->query(
    "SELECT id_encargado, nombre, apellido
     FROM encargado
     ORDER BY apellido, nombre"
);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Registro de préstamos | BandaStock</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Roboto:wght@400;500&display=swap"
          rel="stylesheet">

    <style>
        :root {
            --azul: #102A43;
            --dorado: #D4A72C;
            --blanco: #FFFFFF;
            --fondo: #F4F6F9;
            --texto: #263445;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            background: var(--fondo);
            color: var(--texto);
            font-family: 'Roboto', sans-serif;
        }

        .main-wrapper {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 25px 15px;
        }

        .card {
            width: 100%;
            max-width: 780px;
            background: var(--blanco);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 22px #102A431A;
        }

        .card-header {
            background: var(--azul);
            color: var(--blanco);
            padding: 25px 30px;
            border-bottom: 5px solid var(--dorado);
        }

        .card-header h2 {
            margin: 0 0 5px;
            font-family: 'Poppins', sans-serif;
        }

        .card-header p {
            margin: 0;
            color: #E3EAF1;
        }

        form { padding: 28px 30px; }

        .grid-2 {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            margin-bottom: 18px;
        }

        label {
            color: var(--azul);
            font-family: 'Poppins', sans-serif;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 7px;
        }

        input, select {
            width: 100%;
            padding: 12px;
            border: 1px solid #CCD5DF;
            border-radius: 6px;
            font-family: 'Roboto', sans-serif;
            font-size: 14px;
            background: var(--blanco);
        }

        input:focus, select:focus {
            outline: none;
            border-color: var(--dorado);
            box-shadow: 0 0 0 3px #D4A72C30;
        }

        .btn-submit {
            width: 100%;
            padding: 13px;
            border: none;
            border-radius: 6px;
            background: var(--dorado);
            color: var(--azul);
            font-family: 'Poppins', sans-serif;
            font-weight: 700;
            cursor: pointer;
        }

        .btn-submit:hover { background: #E4BA48; }

        .alert {
            margin: 20px 30px 0;
            padding: 12px;
            border-radius: 6px;
        }

        .success { background: #E7F6EC; color: #176536; }
        .error { background: #FCE8E8; color: #A32121; }

        .acciones {
            padding: 0 30px 25px;
            text-align: center;
        }

        a { color: var(--azul); }

        @media (max-width: 600px) {
            .grid-2 { grid-template-columns: 1fr; gap: 0; }
            form { padding: 22px 18px; }
            .card-header { padding: 22px 18px; }
            .alert { margin-left: 18px; margin-right: 18px; }
        }
    </style>
</head>

<body>
<div class="main-wrapper">
    <div class="card">

        <div class="card-header">
            <h2>Registro de préstamos</h2>
            <p>Registra la asignación de un instrumento a un integrante.</p>
        </div>

        <?php if ($mensaje !== ''): ?>
            <div class="alert <?php echo $tipo_alerta; ?>">
                <?php echo htmlspecialchars($mensaje); ?>
            </div>
        <?php endif; ?>

        <?php if ($rol === 'encargado'): ?>

        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>"
              method="POST">

            <div class="grid-2">

                <div class="form-group">
                    <label for="id_instrumento">Instrumento:</label>
                    <select name="id_instrumento" id="id_instrumento" required>
                        <option value="">Selecciona un instrumento</option>
                        <?php if ($instrumentos): ?>
                            <?php while ($fila = $instrumentos->fetch_assoc()): ?>
                                <option value="<?php echo (int)$fila['id_instrumento']; ?>">
                                    <?php echo htmlspecialchars(
                                        $fila['nombre'] . ' - Serie ' . $fila['num_serie']
                                    ); ?>
                                </option>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="id_integrante">Integrante:</label>
                    <select name="id_integrante" id="id_integrante" required>
                        <option value="">Selecciona un integrante</option>
                        <?php if ($integrantes): ?>
                            <?php while ($fila = $integrantes->fetch_assoc()): ?>
                                <option value="<?php echo (int)$fila['id_integrante']; ?>">
                                    <?php echo htmlspecialchars(
                                        $fila['nombre'] . ' ' . $fila['apellido']
                                    ); ?>
                                </option>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="id_encargado">Encargado responsable:</label>
                    <select name="id_encargado" id="id_encargado" required>
                        <option value="">Selecciona un encargado</option>
                        <?php if ($encargados): ?>
                            <?php while ($fila = $encargados->fetch_assoc()): ?>
                                <option value="<?php echo (int)$fila['id_encargado']; ?>">
                                    <?php echo htmlspecialchars(
                                        $fila['nombre'] . ' ' . $fila['apellido']
                                    ); ?>
                                </option>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="fecha_prestamo">Fecha del préstamo:</label>
                    <input type="date" name="fecha_prestamo"
                           id="fecha_prestamo" required>
                </div>

                <div class="form-group">
                    <label for="fecha_devolucion_prevista">
                        Fecha prevista de devolución:
                    </label>
                    <input type="date" name="fecha_devolucion_prevista"
                           id="fecha_devolucion_prevista" required>
                </div>

            </div>

            <button type="submit" class="btn-submit">
                Guardar préstamo
            </button>
        </form>

        <?php else: ?>
            <div class="alert error">
                Tu rol permite consultar e imprimir, pero no registrar préstamos.
            </div>
        <?php endif; ?>

        <div class="acciones">
            <a href="bienvenida.php">Volver al menú principal</a>
        </div>

    </div>
</div>
</body>
</html>