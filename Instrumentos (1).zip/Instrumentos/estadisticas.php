
<?php
session_start();
require_once "conexion.php";

/*
|--------------------------------------------------------------------------
| BandaStock - Estadísticas generales
|--------------------------------------------------------------------------
| Usa la conexión $conexion de conexion.php.
| Las fechas se aplican a las tablas que tengan una columna de fecha
| reconocida. Si una tabla no tiene una, se muestra su total histórico.
|--------------------------------------------------------------------------
*/

// Verificar sesión
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Tablas que se incluirán en las estadísticas
$tablas = [
    "Instrumentos"  => "Instrumentos",
    "Integrantes"   => "integrantes",
    "Préstamos"     => "prestamos",
    "Mantenimientos"=> "mantenimientos"
];

// Columnas de fecha posibles
$columnasFecha = [
    "fecha",
    "fecha_registro",
    "fecha_creacion",
    "fecha_creación",
    "fecha_ingreso",
    "fecha_prestamo",
    "fecha_préstamo",
    "fecha_mantenimiento",
    "fecha_inicio",
    "created_at",
    "created",
    "date_created"
];

// Filtros recibidos
$desde = isset($_GET['desde']) ? trim($_GET['desde']) : "";
$hasta = isset($_GET['hasta']) ? trim($_GET['hasta']) : "";
$modulo = isset($_GET['modulo']) ? trim($_GET['modulo']) : "todos";

// Validar formato de fechas
if ($desde !== "" && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $desde)) {
    $desde = "";
}

if ($hasta !== "" && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $hasta)) {
    $hasta = "";
}

// Evitar rangos invertidos
if ($desde !== "" && $hasta !== "" && $desde > $hasta) {
    $temporal = $desde;
    $desde = $hasta;
    $hasta = $temporal;
}

// Comprobar que el módulo solicitado sea válido
if ($modulo !== "todos" && !array_key_exists($modulo, $tablas)) {
    $modulo = "todos";
}

/**
 * Obtiene los nombres de las columnas de una tabla.
 */
function obtenerColumnas($conexion, $tabla)
{
    $columnas = [];

    $resultado = $conexion->query("SHOW COLUMNS FROM `$tabla`");

    if ($resultado) {
        while ($fila = $resultado->fetch_assoc()) {
            $columnas[] = $fila['Field'];
        }

        $resultado->free();
    }

    return $columnas;
}

/**
 * Detecta una columna que pueda contener fechas.
 */
function detectarColumnaFecha($columnas, $posibles)
{
    foreach ($posibles as $posible) {
        foreach ($columnas as $columna) {
            if (strtolower($columna) === strtolower($posible)) {
                return $columna;
            }
        }
    }

    // Como alternativa, buscar columnas cuyo nombre comience con "fecha"
    foreach ($columnas as $columna) {
        if (stripos($columna, "fecha") === 0) {
            return $columna;
        }
    }

    return null;
}

/**
 * Cuenta los registros de una tabla aplicando filtros de fecha
 * cuando existe una columna de fecha reconocida.
 */
function contarRegistros(
    $conexion,
    $tabla,
    $columnaFecha,
    $desde,
    $hasta
) {
    $total = 0;
    $filtrado = false;

    $sql = "SELECT COUNT(*) AS total FROM `$tabla`";
    $condiciones = [];
    $parametros = [];
    $tipos = "";

    if ($columnaFecha !== null) {
        if ($desde !== "") {
            $condiciones[] = "DATE(`$columnaFecha`) >= ?";
            $parametros[] = $desde;
            $tipos .= "s";
            $filtrado = true;
        }

        if ($hasta !== "") {
            $condiciones[] = "DATE(`$columnaFecha`) <= ?";
            $parametros[] = $hasta;
            $tipos .= "s";
            $filtrado = true;
        }
    }

    if (!empty($condiciones)) {
        $sql .= " WHERE " . implode(" AND ", $condiciones);
    }

    if (!empty($parametros)) {
        $consulta = $conexion->prepare($sql);

        if ($consulta) {
            $consulta->bind_param($tipos, ...$parametros);
            $consulta->execute();

            $resultado = $consulta->get_result();

            if ($resultado) {
                $fila = $resultado->fetch_assoc();
                $total = (int) $fila['total'];
            }

            $consulta->close();
        }
    } else {
        $resultado = $conexion->query($sql);

        if ($resultado) {
            $fila = $resultado->fetch_assoc();
            $total = (int) $fila['total'];
            $resultado->free();
        }
    }

    return [
        "total" => $total,
        "filtrado" => $filtrado
    ];
}

// Preparar las estadísticas
$estadisticas = [];
$totalGeneral = 0;

foreach ($tablas as $nombre => $tabla) {
    // Si se seleccionó un módulo específico, omitir los demás
    if ($modulo !== "todos" && $modulo !== $nombre) {
        continue;
    }

    $columnas = obtenerColumnas($conexion, $tabla);

    if (empty($columnas)) {
        $estadisticas[$nombre] = [
            "tabla" => $tabla,
            "total" => 0,
            "fecha" => null,
            "filtrado" => false,
            "error" => true
        ];

        continue;
    }

    $columnaFecha = detectarColumnaFecha(
        $columnas,
        $columnasFecha
    );

    $conteo = contarRegistros(
        $conexion,
        $tabla,
        $columnaFecha,
        $desde,
        $hasta
    );

    $estadisticas[$nombre] = [
        "tabla" => $tabla,
        "total" => $conteo["total"],
        "fecha" => $columnaFecha,
        "filtrado" => $conteo["filtrado"],
        "error" => false
    ];

    $totalGeneral += $conteo["total"];
}

// Máximo para calcular las barras del gráfico
$maximo = 1;

foreach ($estadisticas as $dato) {
    if ($dato["total"] > $maximo) {
        $maximo = $dato["total"];
    }
}

// Función para escapar texto HTML
function e($texto)
{
    return htmlspecialchars((string) $texto, ENT_QUOTES, "UTF-8");
}

// Fecha y hora de generación
$fechaGeneracion = date("d/m/Y");
$horaGeneracion = date("H:i:s");

// Etiqueta del período
if ($desde !== "" && $hasta !== "") {
    $periodo = date("d/m/Y", strtotime($desde))
        . " al "
        . date("d/m/Y", strtotime($hasta));
} elseif ($desde !== "") {
    $periodo = "Desde " . date("d/m/Y", strtotime($desde));
} elseif ($hasta !== "") {
    $periodo = "Hasta " . date("d/m/Y", strtotime($hasta));
} else {
    $periodo = "Todos los períodos";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Estadísticas | BandaStock</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
        rel="stylesheet"
    >

    <style>
        :root {
            --azul: #10294b;
            --azul-claro: #183b65;
            --dorado: #d4a72c;
            --fondo: #f3f5f9;
            --blanco: #ffffff;
            --texto: #263449;
            --gris: #718096;
            --borde: #e5e9f0;
            --verde: #18865b;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 25px;
            background: var(--fondo);
            color: var(--texto);
            font-family: 'Poppins', sans-serif;
        }

        .contenedor {
            width: 100%;
            max-width: 1250px;
            margin: 0 auto;
        }

        .encabezado {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            padding: 25px 30px;
            margin-bottom: 22px;
            color: white;
            background: linear-gradient(
                135deg,
                var(--azul),
                var(--azul-claro)
            );
            border-bottom: 5px solid var(--dorado);
            border-radius: 12px;
            box-shadow: 0 5px 18px rgba(16, 41, 75, 0.12);
        }

        .encabezado h1 {
            margin: 0 0 6px;
            font-size: 25px;
            font-weight: 700;
        }

        .encabezado p {
            margin: 0;
            color: #e1e9f5;
            font-size: 13px;
        }

        .marca {
            color: var(--dorado);
            font-size: 14px;
            font-weight: 700;
            letter-spacing: 1px;
            white-space: nowrap;
        }

        .acciones {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 20px;
        }

        .boton {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 11px 17px;
            border: none;
            border-radius: 7px;
            font-family: inherit;
            font-size: 12px;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: 0.2s;
        }

        .boton-imprimir {
            background: var(--dorado);
            color: var(--azul);
        }

        .boton-imprimir:hover {
            background: #bd9220;
        }

        .boton-limpiar {
            color: var(--azul);
            background: #e4eaf2;
        }

        .filtros {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 16px;
            align-items: end;
            padding: 22px;
            margin-bottom: 22px;
            background: white;
            border: 1px solid var(--borde);
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(16, 41, 75, 0.04);
        }

        .campo {
            display: flex;
            flex-direction: column;
            gap: 7px;
        }

        .campo label {
            color: var(--azul);
            font-size: 12px;
            font-weight: 600;
        }

        .campo input,
        .campo select {
            width: 100%;
            min-height: 42px;
            padding: 9px 11px;
            color: var(--texto);
            background: white;
            border: 1px solid #d5dce6;
            border-radius: 6px;
            font-family: inherit;
            font-size: 12px;
        }

        .campo input:focus,
        .campo select:focus {
            outline: 2px solid rgba(212, 167, 44, 0.35);
            border-color: var(--dorado);
        }

        .filtro-botones {
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .boton-filtrar {
            min-height: 42px;
            width: 100%;
            background: var(--azul);
            color: white;
        }

        .boton-filtrar:hover {
            background: var(--azul-claro);
        }

        .periodo {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            margin: 0 0 18px;
            color: var(--gris);
            font-size: 12px;
        }

        .periodo strong {
            color: var(--azul);
        }

        .total-general {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
            padding: 23px 27px;
            margin-bottom: 22px;
            color: white;
            background: var(--azul);
            border-left: 6px solid var(--dorado);
            border-radius: 10px;
            box-shadow: 0 4px 14px rgba(16, 41, 75, 0.09);
        }

        .total-general .etiqueta {
            font-size: 13px;
            color: #e1e9f5;
        }

        .total-general .numero {
            margin-top: 5px;
            font-size: 34px;
            font-weight: 700;
            line-height: 1.2;
        }

        .total-icono {
            font-size: 35px;
            color: var(--dorado);
        }

        .tarjetas {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 18px;
            margin-bottom: 22px;
        }

        .tarjeta {
            position: relative;
            overflow: hidden;
            padding: 21px;
            background: white;
            border: 1px solid var(--borde);
            border-radius: 10px;
            box-shadow: 0 3px 12px rgba(16, 41, 75, 0.04);
        }

        .tarjeta::before {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: var(--dorado);
            content: "";
        }

        .tarjeta .nombre {
            margin-bottom: 12px;
            color: var(--gris);
            font-size: 12px;
            font-weight: 500;
        }

        .tarjeta .cantidad {
            color: var(--azul);
            font-size: 29px;
            font-weight: 700;
        }

        .tarjeta .detalle {
            margin-top: 7px;
            color: var(--gris);
            font-size: 10px;
            line-height: 1.6;
        }

        .panel {
            padding: 24px;
            margin-bottom: 22px;
            background: white;
            border: 1px solid var(--borde);
            border-radius: 10px;
            box-shadow: 0 3px 12px rgba(16, 41, 75, 0.04);
        }

        .panel h2 {
            margin: 0 0 5px;
            color: var(--azul);
            font-size: 17px;
        }

        .subtitulo {
            margin: 0 0 25px;
            color: var(--gris);
            font-size: 11px;
        }

        .grafico {
            display: flex;
            flex-direction: column;
            gap: 22px;
        }

        .barra-fila {
            display: grid;
            grid-template-columns: 145px minmax(0, 1fr) 65px;
            align-items: center;
            gap: 13px;
        }

        .barra-nombre {
            color: var(--texto);
            font-size: 12px;
            font-weight: 500;
        }

        .barra-fondo {
            width: 100%;
            height: 23px;
            overflow: hidden;
            background: #edf0f5;
            border-radius: 5px;
        }

        .barra {
            height: 100%;
            min-width: 0;
            background: linear-gradient(
                90deg,
                var(--azul),
                #315985
            );
            border-right: 3px solid var(--dorado);
            border-radius: 5px;
            transition: width 0.3s ease;
        }

        .barra-cantidad {
            color: var(--azul);
            text-align: right;
            font-size: 12px;
            font-weight: 700;
        }

        .tabla-contenedor {
            width: 100%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            color: white;
            background: var(--azul);
        }

        th,
        td {
            padding: 13px 14px;
            text-align: left;
            font-size: 11px;
            border-bottom: 1px solid var(--borde);
        }

        th {
            font-weight: 600;
        }

        tbody tr:nth-child(even) {
            background: #f8f9fc;
        }

        tbody tr:hover {
            background: #f0f3f8;
        }

        .estado {
            display: inline-block;
            padding: 5px 9px;
            color: var(--verde);
            background: #e5f5ee;
            border-radius: 20px;
            font-size: 10px;
            font-weight: 600;
        }

        .estado-historico {
            color: #715a19;
            background: #fff4d5;
        }

        .pie {
            padding: 18px 0 5px;
            margin-top: 10px;
            color: var(--gris);
            border-top: 1px solid var(--borde);
            text-align: right;
            font-size: 10px;
            line-height: 1.8;
        }

        .pie strong {
            color: var(--azul);
        }

        .sin-datos {
            padding: 25px;
            color: var(--gris);
            text-align: center;
            font-size: 12px;
        }

        @media (max-width: 900px) {
            .tarjetas {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .filtros {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        @media (max-width: 560px) {
            body {
                padding: 12px;
            }

            .encabezado {
                align-items: flex-start;
                flex-direction: column;
                padding: 20px;
            }

            .encabezado h1 {
                font-size: 21px;
            }

            .tarjetas {
                grid-template-columns: 1fr;
            }

            .filtros {
                grid-template-columns: 1fr;
            }

            .barra-fila {
                grid-template-columns: 100px minmax(0, 1fr) 40px;
                gap: 8px;
            }

            .barra-nombre {
                font-size: 10px;
            }

            .panel {
                padding: 16px;
            }

            .total-general .numero {
                font-size: 28px;
            }
        }

        @media print {
            body {
                padding: 0 !important;
                background: white !important;
                color: #222 !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }

            .contenedor {
                max-width: none;
            }

            .acciones,
            .filtros {
                display: none !important;
            }

            .encabezado,
            .total-general,
            .tarjeta,
            .panel {
                box-shadow: none !important;
                break-inside: avoid;
            }

            .encabezado {
                border-radius: 0;
            }

            .tarjetas {
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 10px;
            }

            .tarjeta {
                padding: 15px;
            }

            .panel {
                padding: 16px;
            }

            .barra {
                print-color-adjust: exact;
                -webkit-print-color-adjust: exact;
            }

            .pie {
                color: #333;
            }

            @page {
                size: A4 portrait;
                margin: 12mm;
            }
        }
    </style>
</head>

<body>
<div class="contenedor">

    <header class="encabezado">
        <div>
            <h1>Estadísticas generales</h1>
            <p>Resumen de registros del sistema de inventario BandaStock</p>
        </div>

        <div class="marca">BANDASTOCK</div>
    </header>

    <div class="acciones">
        <button
            type="button"
            class="boton boton-imprimir"
            onclick="window.print()"
        >
            🖨️ Imprimir estadísticas
        </button>
    </div>

    <form method="GET" class="filtros">
        <div class="campo">
            <label for="modulo">Módulo</label>

            <select name="modulo" id="modulo">
                <option
                    value="todos"
                    <?= $modulo === "todos" ? "selected" : "" ?>
                >
                    Todos los módulos
                </option>

                <?php foreach ($tablas as $nombre => $tabla): ?>
                    <option
                        value="<?= e($nombre) ?>"
                        <?= $modulo === $nombre ? "selected" : "" ?>
                    >
                        <?= e($nombre) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="campo">
            <label for="desde">Fecha desde</label>

            <input
                type="date"
                id="desde"
                name="desde"
                value="<?= e($desde) ?>"
            >
        </div>

        <div class="campo">
            <label for="hasta">Fecha hasta</label>

            <input
                type="date"
                id="hasta"
                name="hasta"
                value="<?= e($hasta) ?>"
            >
        </div>

        <div class="filtro-botones">
            <button type="submit" class="boton boton-filtrar">
                Aplicar filtros
            </button>

            <a href="estadisticas.php" class="boton boton-limpiar">
                Limpiar
            </a>
        </div>
    </form>

    <div class="periodo">
        <div>
            Período consultado:
            <strong><?= e($periodo) ?></strong>
        </div>

        <div>
            Módulo:
            <strong>
                <?= $modulo === "todos" ? "Todos" : e($modulo) ?>
            </strong>
        </div>
    </div>

    <section class="total-general">
        <div>
            <div class="etiqueta">Total general de registros consultados</div>

            <div class="numero">
                <?= number_format($totalGeneral) ?>
            </div>
        </div>

        <div class="total-icono">▥</div>
    </section>

    <section class="tarjetas">
        <?php foreach ($estadisticas as $nombre => $dato): ?>
            <article class="tarjeta">
                <div class="nombre"><?= e($nombre) ?></div>

                <div class="cantidad">
                    <?= number_format($dato["total"]) ?>
                </div>

                <div class="detalle">
                    <?php if ($dato["error"]): ?>
                        No se pudo consultar esta tabla.
                    <?php elseif ($dato["fecha"] === null && ($desde !== "" || $hasta !== "")): ?>
                        Total histórico: no se detectó una columna de fecha.
                    <?php elseif ($dato["filtrado"]): ?>
                        Registros dentro del período seleccionado.
                    <?php else: ?>
                        Total de registros del módulo.
                    <?php endif; ?>
                </div>
            </article>
        <?php endforeach; ?>
    </section>

    <section class="panel">
        <h2>Gráfico de registros por módulo</h2>

        <p class="subtitulo">
            Comparación de la cantidad de registros según los filtros aplicados.
        </p>

        <?php if (empty($estadisticas)): ?>
            <div class="sin-datos">
                No hay módulos disponibles para mostrar.
            </div>
        <?php else: ?>
            <div class="grafico">
                <?php foreach ($estadisticas as $nombre => $dato): ?>
                    <?php
                        $porcentaje = ($dato["total"] / $maximo) * 100;
                    ?>

                    <div class="barra-fila">
                        <div class="barra-nombre">
                            <?= e($nombre) ?>
                        </div>

                        <div
                            class="barra-fondo"
                            role="img"
                            aria-label="<?= e($nombre) ?>: <?= (int) $dato["total"] ?> registros"
                        >
                            <div
                                class="barra"
                                style="width: <?= $porcentaje ?>%;"
                            ></div>
                        </div>

                        <div class="barra-cantidad">
                            <?= number_format($dato["total"]) ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <section class="panel">
        <h2>Detalle estadístico</h2>

        <p class="subtitulo">
            Cantidad de registros por módulo y método de consulta utilizado.
        </p>

        <div class="tabla-contenedor">
            <table>
                <thead>
                    <tr>
                        <th>N.º</th>
                        <th>Módulo</th>
                        <th>Total de registros</th>
                        <th>Columna de fecha</th>
                        <th>Consulta aplicada</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (empty($estadisticas)): ?>
                        <tr>
                            <td colspan="5" class="sin-datos">
                                No hay registros estadísticos que mostrar.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php $numero = 1; ?>

                        <?php foreach ($estadisticas as $nombre => $dato): ?>
                            <tr>
                                <td><?= $numero++ ?></td>

                                <td><?= e($nombre) ?></td>

                                <td>
                                    <strong>
                                        <?= number_format($dato["total"]) ?>
                                    </strong>
                                </td>

                                <td>
                                    <?= $dato["fecha"] !== null
                                        ? e($dato["fecha"])
                                        : "No detectada" ?>
                                </td>

                                <td>
                                    <?php if ($dato["error"]): ?>
                                        <span class="estado estado-historico">
                                            Error de consulta
                                        </span>
                                    <?php elseif ($dato["fecha"] === null && ($desde !== "" || $hasta !== "")): ?>
                                        <span class="estado estado-historico">
                                            Total histórico
                                        </span>
                                    <?php elseif ($dato["filtrado"]): ?>
                                        <span class="estado">
                                            Filtrado por fecha
                                        </span>
                                    <?php else: ?>
                                        <span class="estado estado-historico">
                                            Todos los registros
                                        </span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>

                <tfoot>
                    <tr>
                        <th colspan="2">TOTAL GENERAL</th>
                        <th><?= number_format($totalGeneral) ?></th>
                        <th colspan="2"></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </section>

    <footer class="pie">
        <div><strong>BandaStock</strong> — Reporte estadístico general</div>
        <div>Período: <?= e($periodo) ?></div>
        <div>Fecha de generación: <?= e($fechaGeneracion) ?></div>
        <div>Hora de generación: <?= e($horaGeneracion) ?></div>
    </footer>

</div>

<script>
    // Evitar seleccionar una fecha final anterior a la fecha inicial.
    const campoDesde = document.getElementById("desde");
    const campoHasta = document.getElementById("hasta");

    function actualizarLimites() {
        campoHasta.min = campoDesde.value || "";

        campoDesde.max = campoHasta.value || "";
    }

    campoDesde.addEventListener("change", actualizarLimites);
    campoHasta.addEventListener("change", actualizarLimites);

    actualizarLimites();
</script>

</body>
</html>
