<?php
session_start();
require_once 'conexion.php';

// Conteo dinámico desde la base de datos
$query_inst = $conexion->query("SELECT COUNT(*) AS total FROM Instrumentos");
$total_inst = ($query_inst) ? $query_inst->fetch_assoc()['total'] : 0;

$query_cat = $conexion->query("SELECT COUNT(*) AS total FROM categoria");
$total_cat = ($query_cat) ? $query_cat->fetch_assoc()['total'] : 0;

$query_integ = $conexion->query("SELECT COUNT(*) AS total FROM integrantes");
$total_integ = ($query_integ) ? $query_integ->fetch_assoc()['total'] : 0;

// Si aún no tienes la tabla prestamos, evita errores controlando la consulta
$total_prest = 0;
$query_prest = $conexion->query("SHOW TABLES LIKE 'prestamos'");
if ($query_prest && $query_prest->num_rows > 0) {
    $res_p = $conexion->query("SELECT COUNT(*) AS total FROM prestamos");
    if ($res_p) $total_prest = $res_p->fetch_assoc()['total'];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenida - BandaStock</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --azul-oscuro: #17365D;
            --dorado: #D4AF37;
            --gris-claro: #F4F6F8;
            --blanco: #ffffff;
            --texto-oscuro: #2b2b2b;
            --borde-color: #e2e8f0;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--gris-claro);
            padding: 2rem;
            color: var(--texto-oscuro);
        }

        /* Banner de Bienvenida */
        .welcome-banner {
            background-color: var(--blanco);
            border-radius: 12px;
            padding: 2.2rem 2.5rem;
            margin-bottom: 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.03);
            border: 1px solid var(--borde-color);
        }

        .welcome-text h2 {
            font-size: 1.8rem;
            color: var(--azul-oscuro);
            margin-bottom: 0.4rem;
            font-weight: 800;
        }

        .welcome-text p {
            color: #718096;
            font-size: 0.98rem;
        }

        .welcome-icon {
            font-size: 3rem;
            color: var(--dorado);
            background-color: #fdf8eb;
            width: 75px;
            height: 75px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* Títulos de sección */
        .section-title {
            font-size: 1.15rem;
            color: var(--azul-oscuro);
            margin-bottom: 1rem;
            font-weight: 700;
        }

        /* Rejilla de Tarjetas de Estadísticas */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
            gap: 1.2rem;
            margin-bottom: 2.2rem;
        }

        .stat-card {
            background-color: var(--blanco);
            border-radius: 10px;
            padding: 1.3rem;
            border: 1px solid var(--borde-color);
            box-shadow: 0 2px 10px rgba(0,0,0,0.02);
        }

        .stat-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 0.8rem;
        }

        .stat-icon {
            width: 38px;
            height: 38px;
            background-color: #fdf8eb;
            color: var(--dorado);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
        }

        .stat-title {
            font-weight: 600;
            color: #4a5568;
            font-size: 0.9rem;
        }

        .stat-number {
            font-size: 2rem;
            font-weight: 800;
            color: var(--azul-oscuro);
            margin-bottom: 0.2rem;
        }

        .stat-desc {
            font-size: 0.78rem;
            color: #a0aec0;
        }

        /* Acciones Rápidas */
        .actions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.2rem;
            margin-bottom: 2rem;
        }

        .action-card {
            background-color: var(--blanco);
            border-radius: 10px;
            padding: 1.2rem 1.4rem;
            border: 1px solid var(--borde-color);
            display: flex;
            align-items: center;
            justify-content: space-between;
            text-decoration: none;
            color: inherit;
            transition: all 0.2s;
            box-shadow: 0 2px 10px rgba(0,0,0,0.02);
        }

        .action-card:hover {
            border-color: var(--dorado);
            box-shadow: 0 4px 12px rgba(212, 175, 55, 0.12);
        }

        .action-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .action-info h4 {
            color: var(--azul-oscuro);
            font-size: 0.92rem;
            margin-bottom: 2px;
            font-weight: 700;
        }

        .action-info p {
            font-size: 0.78rem;
            color: #718096;
            max-width: 200px;
        }

        .action-arrow {
            color: var(--dorado);
            font-size: 1rem;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <!-- Banner Principal -->
    <div class="welcome-banner">
        <div class="welcome-text">
            <h2>¡Bienvenido a BandaStock!</h2>
            <p>Administra y controla los instrumentos de la banda de paz desde un solo lugar.</p>
        </div>
        <div class="welcome-icon">
            <i class="fa-solid fa-music"></i>
        </div>
    </div>

    <!-- Resumen del inventario -->
    <h3 class="section-title">Resumen del inventario</h3>
    <div class="stats-grid">
        <!-- Instrumentos -->
        <div class="stat-card">
            <div class="stat-header">
                <div class="stat-icon"><i class="fa-solid fa-drum"></i></div>
                <span class="stat-title">Instrumentos</span>
            </div>
            <div class="stat-number"><?php echo $total_inst; ?></div>
            <div class="stat-desc">Total de instrumentos registrados</div>
        </div>

        <!-- Categorías -->
        <div class="stat-card">
            <div class="stat-header">
                <div class="stat-icon"><i class="fa-solid fa-tags"></i></div>
                <span class="stat-title">Categorías</span>
            </div>
            <div class="stat-number"><?php echo $total_cat; ?></div>
            <div class="stat-desc">Categorías registradas</div>
        </div>

        <!-- Integrantes (Reemplaza a Proveedores) -->
        <div class="stat-card">
            <div class="stat-header">
                <div class="stat-icon"><i class="fa-solid fa-users"></i></div>
                <span class="stat-title">Integrantes</span>
            </div>
            <div class="stat-number"><?php echo $total_integ; ?></div>
            <div class="stat-desc">Integrantes registrados</div>
        </div>

        <!-- Estadísticas (Reemplaza a Almacenes) -->
        <div class="stat-card">
            <div class="stat-header">
                <div class="stat-icon"><i class="fa-solid fa-chart-pie"></i></div>
                <span class="stat-title">Estadísticas</span>
            </div>
            <div class="stat-number"><?php echo $total_prest; ?></div>
            <div class="stat-desc">Préstamos/Operaciones realizadas</div>
        </div>
    </div>

    <!-- Acciones rápidas -->
    <h3 class="section-title">Acciones rápidas</h3>
    <div class="actions-grid">
        <a href="#" class="action-card">
            <div class="action-info">
                <div class="stat-icon"><i class="fa-solid fa-drum"></i></div>
                <div>
                    <h4>Registrar instrumento</h4>
                    <p>Agrega un nuevo instrumento al inventario.</p>
                </div>
            </div>
            <span class="action-arrow">→</span>
        </a>

        <a href="#" class="action-card">
            <div class="action-info">
                <div class="stat-icon"><i class="fa-solid fa-right-left"></i></div>
                <div>
                    <h4>Registrar préstamo</h4>
                    <p>Asigna un instrumento a un integrante.</p>
                </div>
            </div>
            <span class="action-arrow">→</span>
        </a>

        <a href="consultar_instrumento.php" target="_parent" class="action-card">
            <div class="action-info">
                <div class="stat-icon"><i class="fa-solid fa-magnifying-glass"></i></div>
                <div>
                    <h4>Consultar inventario</h4>
                    <p>Busca y revisa la información de los instrumentos.</p>
                </div>
            </div>
            <span class="action-arrow">→</span>
        </a>
    </div>

</body>
</html>