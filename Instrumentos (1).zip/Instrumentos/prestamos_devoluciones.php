
<?php
require_once "conexion.php";

$buscar = trim($_GET["buscar"] ?? "");
$filtro = trim($_GET["filtro"] ?? "todos");

$sql = "
    SELECT
        p.id_prestamo,
        p.fecha_prestamo,
        p.fecha_devolucion_prevista,
        p.fecha_devolucion_real,
        p.estado_prestamo,

        i.nombre AS nombre_instrumento,
        i.num_serie,
        i.marca,

        inte.nombre AS nombre_integrante,
        inte.apellido AS apellido_integrante,

        e.nombre AS nombre_encargado,
        e.apellido AS apellido_encargado

    FROM prestamos p

    INNER JOIN Instrumentos i
        ON p.id_instrumento = i.id_instrumento

    INNER JOIN integrantes inte
        ON p.id_integrante = inte.id_integrante

    LEFT JOIN encargado e
        ON p.id_encargado = e.id_encargado

    WHERE 1=1
";

if ($buscar !== "") {
    $sql .= "
        AND (
            CAST(p.id_prestamo AS CHAR) LIKE ?
            OR i.nombre LIKE ?
            OR CAST(i.num_serie AS CHAR) LIKE ?
            OR i.marca LIKE ?
            OR inte.nombre LIKE ?
            OR inte.apellido LIKE ?
            OR CONCAT(inte.nombre, ' ', inte.apellido) LIKE ?
            OR CONCAT(e.nombre, ' ', e.apellido) LIKE ?
            OR p.estado_prestamo LIKE ?
        )
    ";
}

if ($filtro === "activos") {
    $sql .= "
        AND p.fecha_devolucion_real IS NULL
        AND LOWER(TRIM(p.estado_prestamo))
            NOT IN ('devuelto', 'devuelta', 'finalizado',
                    'finalizada', 'cerrado', 'cerrada',
                    'completado', 'completada')
    ";
} elseif ($filtro === "devoluciones") {
    $sql .= "
        AND (
            p.fecha_devolucion_real IS NOT NULL
            OR LOWER(TRIM(p.estado_prestamo))
                IN ('devuelto', 'devuelta', 'finalizado',
                    'finalizada', 'cerrado', 'cerrada',
                    'completado', 'completada')
        )
    ";
}

$sql .= " ORDER BY p.fecha_prestamo DESC, p.id_prestamo DESC";

$stmt = $conexion->prepare($sql);

if (!$stmt) {
    die("Error al preparar la consulta: " .
        htmlspecialchars($conexion->error, ENT_QUOTES, "UTF-8"));
}

if ($buscar !== "") {
    $termino = "%" . $buscar . "%";

    $stmt->bind_param(
        "sssssssss",
        $termino,
        $termino,
        $termino,
        $termino,
        $termino,
        $termino,
        $termino,
        $termino,
        $termino
    );
}

$stmt->execute();
$resultado = $stmt->get_result();

$total = 0;
$activos = 0;
$devoluciones = 0;

if ($resultado) {
    while ($fila = $resultado->fetch_assoc()) {
        $total++;

        $estado = strtolower(trim($fila["estado_prestamo"] ?? ""));

        $estaDevuelto =
            !empty($fila["fecha_devolucion_real"]) ||
            in_array($estado, [
                "devuelto", "devuelta",
                "finalizado", "finalizada",
                "cerrado", "cerrada",
                "completado", "completada"
            ], true);

        if ($estaDevuelto) {
            $devoluciones++;
        } else {
            $activos++;
        }
    }

    $resultado->data_seek(0);
}

function escapar($valor) {
    return htmlspecialchars(
        (string)($valor ?? ""),
        ENT_QUOTES,
        "UTF-8"
    );
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Préstamos y devoluciones | BandaStock</title>

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        :root {
            --azul: #17365D;
            --dorado: #D4AF37;
            --fondo: #F4F6F8;
            --blanco: #FFFFFF;
            --texto: #263238;
            --borde: #DDE3E8;
            --verde: #198754;
            --rojo: #C0392B;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: var(--fondo);
            color: var(--texto);
        }

        header {
            background: var(--azul);
            color: var(--blanco);
            padding: 22px 16px;
            border-bottom: 5px solid var(--dorado);
        }

        .encabezado {
            max-width: 1250px;
            margin: auto;
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .encabezado i {
            color: var(--dorado);
            font-size: 32px;
        }

        header h1 {
            margin: 0;
            font-size: 25px;
        }

        header p {
            margin: 6px 0 0;
            color: #E5EAF0;
            font-size: 14px;
        }

        main {
            max-width: 1250px;
            margin: 28px auto;
            padding: 0 16px;
        }

        .resumen {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 16px;
            margin-bottom: 22px;
        }

        .tarjeta {
            background: var(--blanco);
            border-radius: 10px;
            padding: 20px;
            border-left: 5px solid var(--dorado);
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.06);
        }

        .tarjeta i {
            color: var(--azul);
            font-size: 23px;
            margin-bottom: 10px;
        }

        .tarjeta p {
            margin: 0 0 7px;
            color: #5F6B76;
        }

        .tarjeta h2 {
            margin: 0;
            color: var(--azul);
            font-size: 28px;
        }

        .panel {
            background: var(--blanco);
            border-radius: 10px;
            padding: 22px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.06);
        }

        .panel h2 {
            color: var(--azul);
            margin-top: 0;
            font-size: 20px;
        }

        .buscador {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 20px;
        }

        .buscador input,
        .buscador select {
            flex: 1;
            min-width: 180px;
            padding: 12px;
            border: 1px solid var(--borde);
            border-radius: 6px;
            font-size: 14px;
            background: white;
        }

        .boton {
            border: none;
            border-radius: 6px;
            padding: 12px 16px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .boton-buscar {
            background: var(--azul);
            color: white;
        }

        .boton-limpiar {
            background: var(--dorado);
            color: #17212B;
        }

        .tabla-contenedor {
            width: 100%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            min-width: 1200px;
            border-collapse: collapse;
        }

        thead {
            background: var(--azul);
            color: white;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid var(--borde);
            vertical-align: top;
        }

        th {
            font-size: 13px;
            white-space: nowrap;
        }

        td {
            font-size: 13px;
            line-height: 1.5;
        }

        tbody tr:hover {
            background: #F8FAFC;
        }

        .estado {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            white-space: nowrap;
        }

        .activo {
            background: #FBE2E0;
            color: #922B21;
        }

        .devuelto {
            background: #D9F2E3;
            color: #17663A;
        }

        .sin-resultados {
            text-align: center;
            padding: 25px;
            color: #64717D;
        }

        .nota {
            color: #64717D;
            font-size: 13px;
            line-height: 1.5;
            margin-top: 16px;
        }

        @media (max-width: 700px) {
            .resumen {
                grid-template-columns: 1fr;
            }

            .buscador {
                flex-direction: column;
            }

            .buscador input,
            .buscador select {
                width: 100%;
            }

            .boton {
                width: 100%;
            }

            .panel {
                padding: 15px;
            }

            header h1 {
                font-size: 21px;
            }
        }
    </style>
</head>

<body>

<header>
    <div class="encabezado">
        <i class="fa-solid fa-right-left"></i>
        <div>
            <h1>BandaStock</h1>
            <p>Consulta de préstamos y devoluciones</p>
        </div>
    </div>
</header>

<main>

    <section class="resumen">
        <div class="tarjeta">
            <i class="fa-solid fa-list"></i>
            <p>Préstamos encontrados</p>
            <h2><?= $total ?></h2>
        </div>

        <div class="tarjeta">
            <i class="fa-solid fa-clock"></i>
            <p>Préstamos activos</p>
            <h2><?= $activos ?></h2>
        </div>

        <div class="tarjeta">
            <i class="fa-solid fa-circle-check"></i>
            <p>Devoluciones registradas</p>
            <h2><?= $devoluciones ?></h2>
        </div>
    </section>

    <section class="panel">
        <h2>
            <i class="fa-solid fa-magnifying-glass"></i>
            Buscar préstamos y devoluciones
        </h2>

        <form method="GET" class="buscador">
            <input
                type="text"
                name="buscar"
                placeholder="ID, instrumento, serie, integrante o encargado..."
                value="<?= escapar($buscar) ?>"
            >

            <select name="filtro">
                <option value="todos"
                    <?= $filtro === "todos" ? "selected" : "" ?>>
                    Todos los registros
                </option>

                <option value="activos"
                    <?= $filtro === "activos" ? "selected" : "" ?>>
                    Préstamos activos
                </option>

                <option value="devoluciones"
                    <?= $filtro === "devoluciones" ? "selected" : "" ?>>
                    Devoluciones
                </option>
            </select>

            <button type="submit" class="boton boton-buscar">
                <i class="fa-solid fa-search"></i> Buscar
            </button>

            <a href="prestamos_devoluciones.php"
               class="boton boton-limpiar">
                <i class="fa-solid fa-rotate-left"></i> Limpiar
            </a>
        </form>

        <div class="tabla-contenedor">
            <table>
                <thead>
                    <tr>
                        <th>ID préstamo</th>
                        <th>Instrumento</th>
                        <th>Número de serie</th>
                        <th>Integrante</th>
                        <th>Encargado</th>
                        <th>Fecha de préstamo</th>
                        <th>Devolución prevista</th>
                        <th>Devolución real</th>
                        <th>Estado</th>
                    </tr>
                </thead>

                <tbody>
                <?php if ($resultado && $resultado->num_rows > 0): ?>
                    <?php while ($fila = $resultado->fetch_assoc()): ?>
                        <?php
                            $estadoTexto = trim(
                                $fila["estado_prestamo"] ?? ""
                            );

                            $estadoMinuscula = strtolower($estadoTexto);

                            $estaDevuelto =
                                !empty($fila["fecha_devolucion_real"]) ||
                                in_array($estadoMinuscula, [
                                    "devuelto", "devuelta",
                                    "finalizado", "finalizada",
                                    "cerrado", "cerrada",
                                    "completado", "completada"
                                ], true);

                            $clase = $estaDevuelto
                                ? "devuelto"
                                : "activo";

                            $etiqueta = $estaDevuelto
                                ? "Devuelto"
                                : "Activo";
                        ?>

                        <tr>
                            <td><?= escapar($fila["id_prestamo"]) ?></td>

                            <td>
                                <strong>
                                    <?= escapar($fila["nombre_instrumento"]) ?>
                                </strong>
                                <br>
                                <?= escapar($fila["marca"]) ?>
                            </td>

                            <td><?= escapar($fila["num_serie"]) ?></td>

                            <td>
                                <?= escapar(
                                    trim(
                                        ($fila["nombre_integrante"] ?? "") . " " .
                                        ($fila["apellido_integrante"] ?? "")
                                    )
                                ) ?>
                            </td>

                            <td>
                                <?= escapar(
                                    trim(
                                        ($fila["nombre_encargado"] ?? "") . " " .
                                        ($fila["apellido_encargado"] ?? "")
                                    ) ?: "Sin asignar"
                                ) ?>
                            </td>

                            <td><?= escapar($fila["fecha_prestamo"]) ?></td>

                            <td>
                                <?= escapar($fila["fecha_devolucion_prevista"]) ?>
                            </td>

                            <td>
                                <?= !empty($fila["fecha_devolucion_real"])
                                    ? escapar($fila["fecha_devolucion_real"])
                                    : "Sin devolver" ?>
                            </td>

                            <td>
                                <span class="estado <?= $clase ?>">
                                    <?= escapar($etiqueta) ?>
                                </span>
                                <br>
                                <small><?= escapar($estadoTexto) ?></small>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" class="sin-resultados">
                            <i class="fa-solid fa-circle-info"></i>
                            No se encontraron préstamos ni devoluciones.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <p class="nota">
            Un préstamo se considera devuelto cuando tiene una fecha de
            devolución real o un estado reconocido como devuelto, finalizado,
            cerrado o completado. Los demás registros se muestran como activos.
            Ajusta estas condiciones si tu sistema utiliza otros valores
            en estado_prestamo.
        </p>
    </section>

</main>

</body>
</html>

<?php
$stmt->close();
$conexion->close();
?>
