
<?php
session_start();
require_once 'conexion.php';

// VERIFICAR SESIÓN
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

$rolSesion = strtolower(trim($_SESSION['rol'] ?? ''));

if (!in_array($rolSesion, ['encargado', 'usuario'], true)) {
    header("Location: bienvenida.php");
    exit();
}

$mensaje = '';
$tipo_alerta = '';

$nombre = '';
$apellido = '';
$correo = '';
$rol_encargado = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // SOLO EL ENCARGADO PUEDE REGISTRAR
    if ($rolSesion !== 'encargado') {
        http_response_code(403);
        exit('No tienes permiso para registrar encargados.');
    }

    $nombre = trim($_POST['nombre'] ?? '');
    $apellido = trim($_POST['apellido'] ?? '');
    $correo = trim($_POST['correo'] ?? '');
    $rol_encargado = trim($_POST['rol'] ?? '');

    if (
        $nombre === '' ||
        $apellido === '' ||
        $correo === '' ||
        $rol_encargado === ''
    ) {
        $mensaje = 'Todos los campos son obligatorios.';
        $tipo_alerta = 'error';

    } elseif (
        mb_strlen($nombre) > 50 ||
        mb_strlen($apellido) > 50 ||
        mb_strlen($correo) > 50 ||
        mb_strlen($rol_encargado) > 50
    ) {
        $mensaje = 'Uno de los campos supera la longitud permitida.';
        $tipo_alerta = 'error';

    } elseif (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        $mensaje = 'Ingresa un correo electrónico válido.';
        $tipo_alerta = 'error';

    } else {

        // VERIFICAR SI EL CORREO YA ESTÁ REGISTRADO
        $sql = "SELECT id_encargado
                FROM encargado
                WHERE correo = ?";

        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("s", $correo);
        $stmt->execute();

        $existe = $stmt->get_result()->num_rows > 0;
        $stmt->close();

        if ($existe) {
            $mensaje = 'Ya existe un encargado registrado con ese correo.';
            $tipo_alerta = 'error';

        } else {

            // REGISTRAR ENCARGADO
            $sql = "INSERT INTO encargado
                    (nombre, apellido, correo, rol)
                    VALUES (?, ?, ?, ?)";

            $stmt = $conexion->prepare($sql);

            if ($stmt) {
                $stmt->bind_param(
                    "ssss",
                    $nombre,
                    $apellido,
                    $correo,
                    $rol_encargado
                );

                if ($stmt->execute()) {
                    $mensaje = '¡Encargado registrado correctamente!';
                    $tipo_alerta = 'success';

                    // LIMPIAR LOS CAMPOS DESPUÉS DE GUARDAR
                    $nombre = '';
                    $apellido = '';
                    $correo = '';
                    $rol_encargado = '';

                } else {
                    $mensaje = 'No se pudo registrar el encargado.';
                    $tipo_alerta = 'error';
                }

                $stmt->close();

            } else {
                $mensaje = 'Error al preparar el registro.';
                $tipo_alerta = 'error';
            }
        }
    }
}

// CONSULTAR ENCARGADOS
$sql_lista = "SELECT id_encargado, nombre, apellido, correo, rol
              FROM encargado
              ORDER BY apellido, nombre";

$lista = $conexion->query($sql_lista);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Gestión de encargados | BandaStock</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Roboto:wght@400;500&display=swap"
          rel="stylesheet">

    <style>
        :root {
            --azul: #102A43;
            --dorado: #D4A72C;
            --blanco: #FFFFFF;
            --fondo: #F4F6F9;
            --texto: #263445;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            background: var(--fondo);
            color: var(--texto);
            font-family: 'Roboto', sans-serif;
        }

        .main-wrapper {
            max-width: 780px;
            margin: auto;
            padding: 30px 16px;
        }

        .card {
            background: var(--blanco);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 22px #102A431A;
            margin-bottom: 25px;
        }

        .card-header {
            background: var(--azul);
            color: var(--blanco);
            padding: 24px 28px;
            border-bottom: 5px solid var(--dorado);
        }

        .card-header h2 {
            margin: 0 0 5px;
            font-family: 'Poppins', sans-serif;
        }

        .card-header p {
            margin: 0;
            color: #E3EAF1;
        }

        .contenido { padding: 25px 28px; }

        .grid-2 {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            margin-bottom: 18px;
        }

        label {
            margin-bottom: 7px;
            color: var(--azul);
            font-family: 'Poppins', sans-serif;
            font-size: 13px;
            font-weight: 600;
        }

        input, select {
            width: 100%;
            padding: 12px;
            border: 1px solid #CCD5DF;
            border-radius: 6px;
            background: white;
            color: var(--texto);
            font: 14px 'Roboto', sans-serif;
        }

        input:focus, select:focus {
            outline: none;
            border-color: var(--dorado);
            box-shadow: 0 0 0 3px #D4A72C30;
        }

        .btn-submit {
            width: 100%;
            padding: 13px;
            border: none;
            border-radius: 6px;
            background: var(--dorado);
            color: var(--azul);
            font-family: 'Poppins', sans-serif;
            font-weight: 700;
            cursor: pointer;
        }

        .btn-submit:hover { background: #E4BA48; }

        .alert {
            margin: 20px 28px 0;
            padding: 12px;
            border-radius: 6px;
        }

        .success { background: #E7F6EC; color: #176536; }
        .error { background: #FCE8E8; color: #A32121; }

        .table-wrap { overflow-x: auto; }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #E1E7ED;
        }

        th {
            background: var(--azul);
            color: white;
            font-family: 'Poppins', sans-serif;
            white-space: nowrap;
        }

        tr:hover td { background: #F8FAFC; }

        .acciones {
            text-align: center;
            padding: 10px 0 25px;
        }

        .print-btn {
            border: 1px solid var(--azul);
            background: white;
            color: var(--azul);
            padding: 9px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
        }

        a { color: var(--azul); }

        @media (max-width: 600px) {
            .grid-2 { grid-template-columns: 1fr; gap: 0; }
            .contenido { padding: 20px 16px; }
            .card-header { padding: 22px 18px; }
            .alert { margin-left: 18px; margin-right: 18px; }
        }

        @media print {
            body { background: white; }
            .no-print, form, .acciones { display: none !important; }
            .main-wrapper { max-width: none; padding: 0; }
            .card { box-shadow: none; border: 1px solid #ccc; }
            .card-header {
                background: white;
                color: black;
                border-bottom: 2px solid #777;
            }
            .card-header p { color: black; }
            th { background: #eee; color: black; }
        }
    </style>
</head>

<body>
<div class="main-wrapper">

    <div class="card">
        <div class="card-header">
            <h2>Registro de encargados</h2>
            <p>Ingresa los datos del responsable de los instrumentos.</p>
        </div>

        <?php if ($mensaje !== ''): ?>
            <div class="alert <?php echo $tipo_alerta; ?>">
                <?php echo htmlspecialchars($mensaje); ?>
            </div>
        <?php endif; ?>

        <div class="contenido">

            <?php if ($rolSesion === 'encargado'): ?>

                <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>"
                      method="POST">

                    <div class="grid-2">

                        <div class="form-group">
                            <label for="nombre">Nombre:</label>
                            <input type="text"
                                   name="nombre"
                                   id="nombre"
                                   maxlength="50"
                                   value="<?php echo htmlspecialchars($nombre); ?>"
                                   placeholder="Ingresa el nombre"
                                   required>
                        </div>

                        <div class="form-group">
                            <label for="apellido">Apellido:</label>
                            <input type="text"
                                   name="apellido"
                                   id="apellido"
                                   maxlength="50"
                                   value="<?php echo htmlspecialchars($apellido); ?>"
                                   placeholder="Ingresa el apellido"
                                   required>
                        </div>

                        <div class="form-group">
                            <label for="correo">Correo electrónico:</label>
                            <input type="email"
                                   name="correo"
                                   id="correo"
                                   maxlength="50"
                                   value="<?php echo htmlspecialchars($correo); ?>"
                                   placeholder="ejemplo@correo.com"
                                   required>
                        </div>

                        <div class="form-group">
                            <label for="rol">Cargo o rol del encargado:</label>
                            <input type="text"
                                   name="rol"
                                   id="rol"
                                   maxlength="50"
                                   value="<?php echo htmlspecialchars($rol_encargado); ?>"
                                   placeholder="Ej. Encargado de instrumentos"
                                   required>
                        </div>

                    </div>

                    <button type="submit" class="btn-submit">
                        Guardar encargado
                    </button>

                </form>

            <?php else: ?>

                <p>Tu rol permite consultar e imprimir, pero no registrar encargados.</p>

            <?php endif; ?>

        </div>
    </div>

   

    <div class="acciones no-print">
        <a href="bienvenida.php">Volver al menú principal</a>
    </div>

</div>
</body>
</html>
