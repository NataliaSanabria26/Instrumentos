
<?php
session_start();

// Verificar autenticación
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit;
}

$nombre_usuario = $_SESSION['usuario'];
$rol = $_SESSION['rol'] ?? 'Usuario';

// Normalizar rol para evitar problemas entre mayúsculas y minúsculas
$esEncargado = (strcasecmp(trim($rol), 'Encargado') === 0);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BandaStock - Panel Principal</title>

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root {
            --azul-oscuro: #17365D;
            --dorado: #D4AF37;
            --gris-fondo: #F4F6F8;
            --blanco: #FFFFFF;
            --texto-menu: #E2E8F0;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            display: flex;
            min-height: 100vh;
            height: 100vh;
            overflow: hidden;
            background-color: var(--gris-fondo);
        }

        /* MENÚ LATERAL */
        aside {
            width: 270px;
            background-color: var(--azul-oscuro);
            color: var(--texto-menu);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            flex-shrink: 0;
            overflow-y: auto;
        }

        .logo-container {
            padding: 1.5rem;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.4rem;
            font-weight: bold;
            color: var(--blanco);
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }

        .logo-container i {
            color: var(--dorado);
        }

        .menu-list {
            list-style: none;
            padding: 1rem 0;
        }

        .menu-list li a {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 0.85rem 1.5rem;
            color: var(--texto-menu);
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 500;
            transition: all 0.2s ease;
        }

        .menu-list li a:hover,
        .menu-list li a.active {
            background-color: var(--dorado);
            color: var(--azul-oscuro);
            font-weight: 700;
        }

        .menu-list li a i {
            font-size: 1.1rem;
            width: 20px;
            text-align: center;
        }

        .menu-divider {
            border: 0;
            border-top: 1px solid rgba(255,255,255,0.1);
            margin: 0.5rem 1.5rem;
        }

        .menu-section {
            padding: 0.8rem 1.5rem 0.2rem;
            color: var(--dorado);
            font-size: 0.72rem;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* CONTENIDO PRINCIPAL */
        main {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            min-width: 0;
            height: 100vh;
        }

        /* BARRA SUPERIOR */
        header {
            background-color: var(--blanco);
            min-height: 60px;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            border-bottom: 1px solid #E2E8F0;
        }

        .panel-title {
            font-weight: 700;
            color: var(--azul-oscuro);
            font-size: 0.9rem;
            letter-spacing: 0.5px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .user-section,
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-info {
            color: #4A5568;
            font-size: 0.9rem;
            font-weight: 600;
        }

        .user-info > i {
            font-size: 1.3rem;
            color: var(--azul-oscuro);
        }

        .badge-rol {
            background-color: rgba(212, 175, 55, 0.2);
            color: #8C7018;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 700;
        }

        /* ÁREA DONDE SE CARGAN LAS PÁGINAS */
        iframe {
            width: 100%;
            flex-grow: 1;
            border: none;
            background-color: var(--gris-fondo);
        }

        /* RESPONSIVE */
        @media (max-width: 800px) {
            body {
                height: 100vh;
            }

            aside {
                width: 220px;
            }

            header {
                padding: 0 1rem;
            }

            .user-info {
                flex-wrap: wrap;
                justify-content: flex-end;
            }
        }

        @media (max-width: 560px) {
            body {
                overflow: auto;
            }

            aside {
                width: 175px;
            }

            .logo-container {
                padding: 1rem;
                font-size: 1.1rem;
            }

            .menu-list li a {
                padding: 0.8rem;
                gap: 8px;
                font-size: 0.78rem;
            }

            .menu-list li a i {
                font-size: 0.95rem;
                width: 16px;
            }

            .menu-section {
                padding-left: 0.8rem;
                font-size: 0.65rem;
            }

            header {
                min-height: 70px;
            }

            .panel-title {
                font-size: 0.75rem;
            }

            .user-info {
                font-size: 0.75rem;
                gap: 5px;
            }
        }
    </style>
</head>

<body>

    <!-- MENÚ LATERAL -->
    <aside>
        <div>
            <div class="logo-container">
                <i class="fa-solid fa-music"></i>
                <span>BandaStock</span>
            </div>

            <ul class="menu-list">

                <!-- INICIO: AMBOS ROLES -->
                <li>
                    <a href="bienvenida.php"
                       target="contenido"
                       class="active"
                       onclick="activarMenu(this)">
                        <i class="fa-solid fa-house"></i>
                        Inicio
                    </a>
                </li>

                <!-- REGISTROS: SOLO ENCARGADO -->
                <?php if ($esEncargado): ?>

                <li class="menu-section">Registros</li>

                <li>
                    <a href="guardarInstrumento.php"
                       target="contenido"
                       onclick="activarMenu(this)">
                        <i class="fa-solid fa-drum"></i>
                        Registro de instrumentos
                    </a>
                </li>

                <li>
                    <a href="guardarIntegrante.php"
                       target="contenido"
                       onclick="activarMenu(this)">
                        <i class="fa-solid fa-user-plus"></i>
                        Registro de integrantes
                    </a>
                </li>

                <li>
                    <a href="guardarEncargado.php"
                       target="contenido"
                       onclick="activarMenu(this)">
                        <i class="fa-solid fa-user-shield"></i>
                        Registro de encargados
                    </a>
                </li>

                <!-- PRÉSTAMOS Y MANTENIMIENTO: SOLO ENCARGADO -->
                <li class="menu-section">Gestión</li>

                <li>
                    <a href="guardarPrestamo.php"
                       target="contenido"
                       onclick="activarMenu(this)">
                        <i class="fa-solid fa-right-left"></i>
                        Préstamos o asignaciones
                    </a>
                </li>

                <li>
                    <a href="devolucion.php"
                       target="contenido"
                       onclick="activarMenu(this)">
                        <i class="fa-solid fa-rotate-left"></i>
                        Devoluciones
                    </a>
                </li>

                <li>
                    <a href="guardarMantenimiento.php"
                       target="contenido"
                       onclick="activarMenu(this)">
                        <i class="fa-solid fa-wrench"></i>
                        Mantenimientos y reparaciones
                    </a>
                </li>

                <?php endif; ?>

                <!-- CONSULTAS: AMBOS ROLES -->
                <li class="menu-section">Consultas</li>

                <li>
                    <a href="consultar_instrumento.php"
                       target="contenido"
                       onclick="activarMenu(this)">
                        <i class="fa-solid fa-magnifying-glass"></i>
                        Consulta de instrumentos
                    </a>
                </li>

                <li>
                    <a href="consultar_integrantes.php"
                       target="contenido"
                       onclick="activarMenu(this)">
                        <i class="fa-solid fa-users"></i>
                        Consulta de integrantes
                    </a>
                </li>
                
           
             

 <li>
                    <a href="mantenimientos_realizados_pendientes.php"
                       target="contenido"
                       onclick="activarMenu(this)">
                        <i class="fa-solid fa-users"></i>
                        Mantenimientos Realizados
                    </a>
                </li>
                
                               <li>
                    <a href="prestamos_devoluciones.php"
                       target="contenido"
                       onclick="activarMenu(this)">
                        <i class="fa-solid fa-users"></i>
                        Prestamos y Devoluciones
                    </a>
                </li>



                <?php if ($esEncargado): ?>
               
                <li>
                    <a href="estadisticas.php"
                       target="contenido"
                       onclick="activarMenu(this)">
                        <i class="fa-solid fa-chart-column"></i>
                        Estadísticas
                    </a>
                </li>
                <?php endif; ?>

            </ul>
        </div>

        <!-- CERRAR SESIÓN -->
        <ul class="menu-list" style="padding-bottom: 1rem;">
            <hr class="menu-divider">
            <li>
                <a href="logout.php" target="_top">
                    <i class="fa-solid fa-right-from-bracket"></i>
                    Cerrar sesión
                </a>
            </li>
        </ul>
    </aside>

    <!-- PANEL DERECHO -->
    <main>
        <header>
            <div class="panel-title">
                <i class="fa-solid fa-grip" style="color: var(--dorado);"></i>
                PANEL DE USUARIO
            </div>

            <div class="user-section">
                <div class="user-info">
                    <i class="fa-solid fa-circle-user"></i>

                    <span>
                        <?php echo htmlspecialchars($nombre_usuario, ENT_QUOTES, 'UTF-8'); ?>
                    </span>

                    <span class="badge-rol">
                        <?php echo htmlspecialchars($rol, ENT_QUOTES, 'UTF-8'); ?>
                    </span>
                </div>
            </div>
        </header>

        <iframe
            src="bienvenida.php"
            name="contenido"
            title="Contenido de BandaStock">
        </iframe>
    </main>

    <script>
        function activarMenu(elemento) {
            document.querySelectorAll('.menu-list a').forEach(function(link) {
                link.classList.remove('active');
            });

            elemento.classList.add('active');
        }
    </script>

</body>
</html>