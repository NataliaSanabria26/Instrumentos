-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: sql103.infinityfree.com
-- Tiempo de generación: 27-10-2026 a las 10:22:45
-- Versión del servidor: 11.4.13-MariaDB
-- Versión de PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `if0_42365459_instrumentos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

CREATE TABLE `categoria` (
  `id_categoria` int(11) NOT NULL,
  `nombre_categoria` varchar(50) NOT NULL,
  `descripcion` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `categoria`
--

INSERT INTO `categoria` (`id_categoria`, `nombre_categoria`, `descripcion`) VALUES
(1, 'Viento Metal', 'Instrumentos como trompeta, trombón y tuba'),
(2, 'Viento Madera', 'Instrumentos como el saxofón'),
(3, 'Percusión', 'Instrumentos como bombo, lira y tambor');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `encargado`
--

CREATE TABLE `encargado` (
  `id_encargado` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `correo` varchar(50) NOT NULL,
  `rol` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `encargado`
--

INSERT INTO `encargado` (`id_encargado`, `nombre`, `apellido`, `correo`, `rol`) VALUES
(1, 'Pedro', 'Tobar', 'pedro.tobar@escuela.edu', 'Encargado General de Instrumentos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Instrumentos`
--

CREATE TABLE `Instrumentos` (
  `id_instrumento` int(11) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `num_serie` int(11) NOT NULL,
  `marca` varchar(50) NOT NULL,
  `estado` varchar(50) NOT NULL,
  `disponibilidad` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `Instrumentos`
--

INSERT INTO `Instrumentos` (`id_instrumento`, `id_categoria`, `nombre`, `num_serie`, `marca`, `estado`, `disponibilidad`) VALUES
(1, 1, 'Trompeta', 5001, 'Bach', 'Excelente', 'Disponible'),
(2, 1, 'Trompeta', 5002, 'Yamaha', 'Bueno', 'Prestado'),
(3, 1, 'Trombón', 5003, 'King', 'Bueno', 'Disponible'),
(4, 1, 'Trombón', 5004, 'Bach', 'Regular', 'Mantenimiento'),
(5, 1, 'Tuba', 5005, 'Miraphone', 'Excelente', 'Disponible'),
(6, 2, 'Saxofón', 5006, 'Yamaha', 'Excelente', 'Prestado'),
(7, 2, 'Saxofón', 5007, 'Selmer', 'Bueno', 'Disponible'),
(8, 2, 'Saxofón', 5008, 'Jupiter', 'Regular', 'Mantenimiento'),
(9, 3, 'Bombo', 5009, 'Pearl', 'Excelente', 'Disponible'),
(10, 3, 'Bombo', 5010, 'Ludwig', 'Bueno', 'Prestado'),
(11, 3, 'Lira', 5011, 'Adams', 'Excelente', 'Disponible'),
(12, 3, 'Lira', 5012, 'Yamaha', 'Bueno', 'Disponible'),
(13, 3, 'Tambor', 5013, 'Mapex', 'Excelente', 'Prestado'),
(14, 3, 'Tambor', 5014, 'Pearl', 'Regular', 'Mantenimiento'),
(15, 3, 'Tambor', 5015, 'Tama', 'Bueno', 'Disponible'),
(16, 3, 'bombo', 11522, 'Pearl', 'Dañado', 'Disponible');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `integrantes`
--

CREATE TABLE `integrantes` (
  `id_integrante` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `NIE` int(11) NOT NULL,
  `seccion_grado` varchar(50) NOT NULL,
  `telefono` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `integrantes`
--

INSERT INTO `integrantes` (`id_integrante`, `nombre`, `apellido`, `NIE`, `seccion_grado`, `telefono`) VALUES
(1, 'Natalia', 'Sanabria', 1001, '3-1', 77618364),
(2, 'Carlos', 'Martínez', 1002, '3-1', 77618365),
(3, 'Sofía', 'Hernández', 1003, '3-2', 77618366),
(4, 'Alejandro', 'Rodríguez', 1004, '3-1', 77618367),
(5, 'Valeria', 'Guevara', 1005, '3-2', 77618368),
(6, 'Diego', 'Flores', 1006, '3-3', 77618369),
(7, 'Lucía', 'Ramírez', 1007, '3-2', 77618370),
(8, 'Mateo', 'Benítez', 1008, '3-3', 77618371),
(9, 'Valeria', 'Rivas', 1009, '3-4', 77618372),
(10, 'Gabriel', 'Ortiz', 1010, '3-4', 77618373),
(11, 'Camila', 'Morales', 1011, '3-5', 77618374),
(12, 'Daniel', 'Castillo', 1012, '3-5', 77618375),
(13, 'Mariana', 'Vásquez', 1013, '3-1', 77618376),
(14, 'Fernando', 'Mendoza', 1014, '3-2', 77618377),
(15, 'Andrea', 'Cruz', 1015, '3-3', 77618378),
(16, 'Samuel', 'Reyes', 1016, '3-4', 77618379),
(17, 'Daniela', 'Aguilar', 1017, '3-5', 77618380),
(18, 'Joaquín', 'Navarro', 1018, '3-1', 77618381),
(19, 'Elena', 'Delgado', 1019, '3-2', 77618382),
(20, 'Adrian', 'Sánchez', 1020, '3-3', 77618383);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mantenimientos`
--

CREATE TABLE `mantenimientos` (
  `id_mantenimiento` int(11) NOT NULL,
  `id_instrumento` int(11) NOT NULL,
  `id_encargado` int(11) NOT NULL,
  `fecha_inicio` date NOT NULL,
  `descripcion_falla` varchar(500) NOT NULL,
  `estado_mantenimiento` varchar(500) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `fecha_ingreso` date NOT NULL,
  `fecha_completado` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `mantenimientos`
--

INSERT INTO `mantenimientos` (`id_mantenimiento`, `id_instrumento`, `id_encargado`, `fecha_inicio`, `descripcion_falla`, `estado_mantenimiento`, `tipo`, `fecha_ingreso`, `fecha_completado`) VALUES
(1, 1, 1, '2026-08-01', 'Limpieza general de pistones', 'Completado', 'Preventivo', '2026-08-01', '2026-08-05'),
(2, 2, 1, '2026-08-10', 'Ajuste de bomba de afinación', 'Completado', 'Preventivo', '2026-08-10', '2026-08-12'),
(3, 3, 1, '2026-08-15', 'Engrase de varas y resortes', 'Completado', 'Preventivo', '2026-08-15', '2026-08-18'),
(4, 4, 1, '2026-10-01', 'Varas trabadas y golpe en campana', 'En proceso', 'Correctivo', '2026-10-01', '2026-10-30'),
(5, 5, 1, '2026-09-01', 'Mantenimiento preventivo anual', 'Completado', 'Preventivo', '2026-09-01', '2026-09-07'),
(6, 6, 1, '2026-09-10', 'Cambio de zapatillas superiores', 'Completado', 'Correctivo', '2026-09-10', '2026-09-15'),
(7, 7, 1, '2026-09-20', 'Ajuste de llaves y lubricación', 'Completado', 'Preventivo', '2026-09-20', '2026-09-23'),
(8, 8, 1, '2026-10-05', 'Zapatillas de llaves dañadas y fuga de aire', 'Pendiente', 'Correctivo', '2026-10-05', '2026-11-02'),
(9, 9, 1, '2026-08-05', 'Ajuste de parches y templadores', 'Completado', 'Preventivo', '2026-08-05', '2026-08-08'),
(10, 10, 1, '2026-08-22', 'Cambio de correa y gancho', 'Completado', 'Correctivo', '2026-08-22', '2026-08-24'),
(11, 11, 1, '2026-09-05', 'Pulido de láminas metálicas', 'Completado', 'Preventivo', '2026-09-05', '2026-09-08'),
(12, 12, 1, '2026-09-12', 'Sustitución de gomas de soporte', 'Completado', 'Preventivo', '2026-09-12', '2026-09-14'),
(13, 13, 1, '2026-09-25', 'Nivelación de parches y bordonero', 'Completado', 'Preventivo', '2026-09-25', '2026-09-28'),
(14, 14, 1, '2026-10-10', 'Parche superior roto y entorchado flojo', 'Completado', 'Correctivo', '2026-10-10', '2026-10-20'),
(15, 15, 1, '2026-08-18', 'Limpieza del vaso y lubricación', 'Completado', 'Preventivo', '2026-08-18', '2026-08-20'),
(16, 1, 1, '2026-10-12', 'Cambio de muelles de pistón', 'En proceso', 'Correctivo', '2026-10-12', '2026-10-28'),
(17, 3, 1, '2026-10-15', 'Ajuste de llave de desagüe', 'Pendiente', 'Preventivo', '2026-10-15', '2026-11-01'),
(18, 7, 1, '2026-10-18', 'Revisión de corchos del tudel', 'En proceso', 'Preventivo', '2026-10-18', '2026-10-29'),
(19, 11, 1, '2026-10-20', 'Soldadura de marco de soporte', 'Pendiente', 'Correctivo', '2026-10-20', '2026-11-05'),
(20, 15, 1, '2026-10-22', 'Cambio de baquetas y bordonero', 'En proceso', 'Preventivo', '2026-10-22', '2026-10-31');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prestamos`
--

CREATE TABLE `prestamos` (
  `id_prestamo` int(11) NOT NULL,
  `id_instrumento` int(11) NOT NULL,
  `id_encargado` int(11) NOT NULL,
  `id_integrante` int(11) NOT NULL,
  `fecha_prestamo` date NOT NULL,
  `fecha_devolucion_prevista` date NOT NULL,
  `fecha_devolucion_real` date NOT NULL,
  `estado_prestamo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `prestamos`
--

INSERT INTO `prestamos` (`id_prestamo`, `id_instrumento`, `id_encargado`, `id_integrante`, `fecha_prestamo`, `fecha_devolucion_prevista`, `fecha_devolucion_real`, `estado_prestamo`) VALUES
(1, 1, 1, 1, '2026-08-10', '2026-08-24', '2026-08-24', 'Devuelto'),
(2, 2, 1, 2, '2026-10-15', '2026-10-29', '2026-10-29', 'Activo'),
(3, 3, 1, 3, '2026-08-20', '2026-09-03', '2026-09-02', 'Devuelto'),
(4, 5, 1, 4, '2026-09-01', '2026-09-15', '2026-09-15', 'Devuelto'),
(5, 6, 1, 5, '2026-10-18', '2026-11-01', '2026-11-01', 'Activo'),
(6, 7, 1, 6, '2026-09-05', '2026-09-19', '2026-09-18', 'Devuelto'),
(7, 9, 1, 7, '2026-08-12', '2026-08-26', '2026-08-25', 'Devuelto'),
(8, 10, 1, 8, '2026-10-20', '2026-11-03', '2026-11-03', 'Activo'),
(9, 11, 1, 9, '2026-09-10', '2026-09-24', '2026-09-24', 'Devuelto'),
(10, 12, 1, 10, '2026-09-15', '2026-09-29', '2026-09-29', 'Devuelto'),
(11, 13, 1, 11, '2026-10-22', '2026-11-05', '2026-11-05', 'Activo'),
(12, 15, 1, 12, '2026-08-25', '2026-09-08', '2026-09-07', 'Devuelto'),
(13, 1, 1, 13, '2026-09-01', '2026-09-15', '2026-09-15', 'Devuelto'),
(14, 3, 1, 14, '2026-09-08', '2026-09-22', '2026-09-21', 'Devuelto'),
(15, 5, 1, 15, '2026-09-18', '2026-10-02', '2026-10-02', 'Devuelto'),
(16, 7, 1, 16, '2026-10-01', '2026-10-15', '2026-10-15', 'Devuelto'),
(17, 9, 1, 17, '2026-09-25', '2026-10-09', '2026-10-09', 'Devuelto'),
(18, 11, 1, 18, '2026-10-05', '2026-10-19', '2026-10-19', 'Devuelto'),
(19, 12, 1, 19, '2026-10-10', '2026-10-24', '2026-10-24', 'Devuelto'),
(20, 15, 1, 20, '2026-10-12', '2026-10-26', '2026-10-26', 'Devuelto');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `clave` varchar(255) NOT NULL,
  `rol` enum('Encargado','Usuario') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `clave`, `rol`) VALUES
(1, 'Encargado', 'camus', 'Encargado'),
(2, 'Usuario', '11522', 'Usuario');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`id_categoria`);

--
-- Indices de la tabla `encargado`
--
ALTER TABLE `encargado`
  ADD PRIMARY KEY (`id_encargado`);

--
-- Indices de la tabla `Instrumentos`
--
ALTER TABLE `Instrumentos`
  ADD PRIMARY KEY (`id_instrumento`),
  ADD KEY `id_categoria` (`id_categoria`);

--
-- Indices de la tabla `integrantes`
--
ALTER TABLE `integrantes`
  ADD PRIMARY KEY (`id_integrante`);

--
-- Indices de la tabla `mantenimientos`
--
ALTER TABLE `mantenimientos`
  ADD PRIMARY KEY (`id_mantenimiento`),
  ADD KEY `id_instrumento` (`id_instrumento`),
  ADD KEY `id_encargado` (`id_encargado`);

--
-- Indices de la tabla `prestamos`
--
ALTER TABLE `prestamos`
  ADD PRIMARY KEY (`id_prestamo`),
  ADD KEY `id_instrumento` (`id_instrumento`),
  ADD KEY `id_encargado` (`id_encargado`),
  ADD KEY `id_integrante` (`id_integrante`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categoria`
--
ALTER TABLE `categoria`
  MODIFY `id_categoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `encargado`
--
ALTER TABLE `encargado`
  MODIFY `id_encargado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `Instrumentos`
--
ALTER TABLE `Instrumentos`
  MODIFY `id_instrumento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `integrantes`
--
ALTER TABLE `integrantes`
  MODIFY `id_integrante` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `mantenimientos`
--
ALTER TABLE `mantenimientos`
  MODIFY `id_mantenimiento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `prestamos`
--
ALTER TABLE `prestamos`
  MODIFY `id_prestamo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `Instrumentos`
--
ALTER TABLE `Instrumentos`
  ADD CONSTRAINT `Instrumentos_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id_categoria`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `mantenimientos`
--
ALTER TABLE `mantenimientos`
  ADD CONSTRAINT `mantenimientos_ibfk_1` FOREIGN KEY (`id_instrumento`) REFERENCES `Instrumentos` (`id_instrumento`) ON UPDATE CASCADE,
  ADD CONSTRAINT `mantenimientos_ibfk_2` FOREIGN KEY (`id_encargado`) REFERENCES `encargado` (`id_encargado`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `prestamos`
--
ALTER TABLE `prestamos`
  ADD CONSTRAINT `prestamos_ibfk_1` FOREIGN KEY (`id_instrumento`) REFERENCES `Instrumentos` (`id_instrumento`) ON UPDATE CASCADE,
  ADD CONSTRAINT `prestamos_ibfk_2` FOREIGN KEY (`id_integrante`) REFERENCES `integrantes` (`id_integrante`) ON UPDATE CASCADE,
  ADD CONSTRAINT `prestamos_ibfk_3` FOREIGN KEY (`id_encargado`) REFERENCES `encargado` (`id_encargado`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
